<?php
define('APP_NAME', 'MySite');
define('APP_URL', 'http://localhost/mysite');
define('WS_PORT', 8080);
define('WS_HOST', '0.0.0.0');

define('UPLOAD_PATH', __DIR__ . '/../public/uploads/');
define('UPLOAD_URL', APP_URL . '/public/uploads/');

// Normal kullanıcı limitleri
define('MAX_AVATAR_SIZE',    10 * 1024 * 1024);   // 10 MB
define('MAX_BG_IMAGE_SIZE',  50 * 1024 * 1024);   // 50 MB
define('MAX_BG_VIDEO_SIZE', 200 * 1024 * 1024);   // 200 MB

// Admin / Root limitleri
define('MAX_AVATAR_SIZE_ADMIN',    50 * 1024 * 1024);    // 50 MB
define('MAX_BG_IMAGE_SIZE_ADMIN', 1024 * 1024 * 1024);   // 1 GB
define('MAX_BG_VIDEO_SIZE_ADMIN', 1024 * 1024 * 1024);   // 1 GB

// Desteklenen MIME türleri (genişletilmiş)
define('ALLOWED_AVATAR_TYPES', [
    'image/jpeg', 'image/jpg', 'image/pjpeg',
    'image/png', 'image/x-png',
    'image/gif',
    'image/webp',
    'image/bmp',
    'image/tiff',
]);

define('ALLOWED_BG_IMAGE_TYPES', [
    'image/jpeg', 'image/jpg', 'image/pjpeg',
    'image/png', 'image/x-png',
    'image/webp',
    'image/gif',
    'image/bmp',
    'image/tiff',
    'image/svg+xml',
]);

define('ALLOWED_BG_VIDEO_TYPES', [
    'video/mp4',
    'video/webm',
    'video/ogg',
    'video/avi',
    'video/x-msvideo',
    'video/quicktime',
    'video/x-ms-wmv',
    'video/mpeg',
    'video/3gpp',
    'video/x-matroska',
]);

// Forum dosya ekleri
define('MAX_FORUM_ATTACHMENT_SIZE',        500 * 1024 * 1024);  // 500 MB
define('MAX_FORUM_ATTACHMENT_SIZE_ADMIN', 1024 * 1024 * 1024);  // 1 GB
define('MAX_FORUM_ATTACHMENTS_PER_POST', 5);

define('LOGIN_MAX_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_MINUTES', 15);

define('RESET_TOKEN_EXPIRY_HOURS', 1);

define('THEMES', ['white', 'red', 'blue', 'black']);
define('DEFAULT_THEME', 'white');
