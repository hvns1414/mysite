<?php
require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';

use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;

$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new \App\ChatServer()
        )
    ),
    WS_PORT,
    WS_HOST
);

echo "WebSocket sunucusu başlatıldı: " . WS_HOST . ":" . WS_PORT . PHP_EOL;
$server->run();
