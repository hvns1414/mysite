<?php
namespace App;

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

class ChatServer implements MessageComponentInterface {

    protected \SplObjectStorage $clients;
    protected array $rooms = [];     // channel => [conn_id => conn]
    protected array $connMeta = [];  // conn_id => ['user_id', 'username', 'display_name', 'avatar', 'role', 'channel', 'room']

    public function __construct() {
        $this->clients = new \SplObjectStorage();
    }

    public function onOpen(ConnectionInterface $conn): void {
        $this->clients->attach($conn);
        $this->connMeta[$conn->resourceId] = [];
    }

    public function onMessage(ConnectionInterface $from, $msg): void {
        try {
            $data = json_decode($msg, true, 512, JSON_THROW_ON_ERROR);
        } catch (\JsonException $e) {
            return;
        }

        $type = $data['type'] ?? '';
        $meta = $this->connMeta[$from->resourceId] ?? [];

        /* ===== Auth: instant chat ===== */
        if ($type === 'auth') {
            $user = $this->fetchUser((int)($data['user_id'] ?? 0));
            if (!$user) { $from->send(json_encode(['type' => 'error', 'message' => 'Yetkilendirme başarısız.'])); return; }
            $channel = in_array($data['channel'] ?? '', ['instant', 'voice']) ? $data['channel'] : 'instant';
            $this->connMeta[$from->resourceId] = [
                'user_id'      => $user['id'],
                'username'     => $user['username'],
                'display_name' => $user['display_name'],
                'avatar'       => $user['avatar'],
                'role'         => $user['role'],
                'channel'      => $channel,
                'room'         => null,
            ];
            $this->joinRoom($from, $channel);
            $this->broadcastOnlineList($channel);
            return;
        }

        /* ===== Chat mesajı ===== */
        if ($type === 'message' && !empty($meta)) {
            $text = trim(substr($data['message'] ?? '', 0, 1000));
            if (empty($text)) return;
            $channel = $meta['channel'] ?? 'instant';
            $msgId   = $this->saveMessage($meta['user_id'], $channel, $text);
            $payload = [
                'type'         => 'message',
                'id'           => $msgId,
                'user_id'      => $meta['user_id'],
                'username'     => $meta['username'],
                'display_name' => $meta['display_name'],
                'avatar'       => $meta['avatar'],
                'role'         => $meta['role'],
                'message'      => $text,
                'time'         => date('H:i'),
                'channel'      => $channel,
            ];
            $this->broadcastToRoom($channel, json_encode($payload));
            return;
        }

        /* ===== Voice: auth ===== */
        if ($type === 'voice_auth') {
            $user = $this->fetchUser((int)($data['user_id'] ?? 0));
            if (!$user) return;
            $room = 'voice_' . preg_replace('/[^a-zA-Z0-9_]/', '', $data['room'] ?? 'main');
            $this->connMeta[$from->resourceId] = [
                'user_id'      => $user['id'],
                'username'     => $user['username'],
                'display_name' => $user['display_name'],
                'avatar'       => $user['avatar'],
                'role'         => $user['role'],
                'channel'      => 'voice_signal',
                'room'         => $room,
            ];
            return;
        }

        /* ===== Voice: odaya katıl ===== */
        if ($type === 'voice_join' && !empty($meta)) {
            $room = $meta['room'] ?? 'voice_room';
            $this->joinRoom($from, $room);
            $this->connMeta[$from->resourceId]['room'] = $room;

            // Mevcut katılımcıları gönder
            $participants = $this->getRoomParticipants($room, $from->resourceId);
            $from->send(json_encode(['type' => 'voice_participants', 'users' => $participants]));

            // Diğerlerine bildir
            $this->broadcastToRoom($room, json_encode([
                'type' => 'voice_joined',
                'user' => ['id' => $meta['user_id'], 'username' => $meta['username'], 'display_name' => $meta['display_name'], 'avatar' => $meta['avatar'], 'role' => $meta['role']],
            ]), $from->resourceId);
            return;
        }

        /* ===== Voice: odadan ayrıl ===== */
        if ($type === 'voice_leave' && !empty($meta)) {
            $room = $meta['room'];
            $this->leaveRoom($from, $room);
            $this->broadcastToRoom($room, json_encode(['type' => 'voice_left', 'user_id' => $meta['user_id']]));
            return;
        }

        /* ===== WebRTC Signaling ===== */
        if (in_array($type, ['offer', 'answer', 'ice_candidate'], true) && !empty($meta)) {
            $to   = (int)($data['to'] ?? 0);
            $room = $meta['room'];
            foreach ($this->rooms[$room] ?? [] as $cid => $conn) {
                $cm = $this->connMeta[$cid] ?? [];
                if (($cm['user_id'] ?? 0) === $to) {
                    $payload          = $data;
                    $payload['from']  = $meta['user_id'];
                    $conn->send(json_encode($payload));
                    break;
                }
            }
        }
    }

    public function onClose(ConnectionInterface $conn): void {
        $meta = $this->connMeta[$conn->resourceId] ?? [];
        if (!empty($meta)) {
            $this->leaveRoom($conn, $meta['channel'] ?? '');
            if (!empty($meta['room'])) {
                $this->leaveRoom($conn, $meta['room']);
                $this->broadcastToRoom($meta['room'], json_encode(['type' => 'voice_left', 'user_id' => $meta['user_id'] ?? 0]));
            }
            if (!empty($meta['channel'])) {
                $this->broadcastOnlineList($meta['channel']);
            }
        }
        $this->clients->detach($conn);
        unset($this->connMeta[$conn->resourceId]);
    }

    public function onError(ConnectionInterface $conn, \Exception $e): void {
        $conn->close();
    }

    /* ===== Helpers ===== */
    private function joinRoom(ConnectionInterface $conn, string $room): void {
        if (empty($room)) return;
        $this->rooms[$room][$conn->resourceId] = $conn;
    }

    private function leaveRoom(ConnectionInterface $conn, string $room): void {
        if (empty($room)) return;
        unset($this->rooms[$room][$conn->resourceId]);
    }

    private function broadcastToRoom(string $room, string $payload, ?int $excludeId = null): void {
        foreach ($this->rooms[$room] ?? [] as $cid => $conn) {
            if ($excludeId !== null && $cid === $excludeId) continue;
            $conn->send($payload);
        }
    }

    private function broadcastOnlineList(string $channel): void {
        $users = [];
        foreach ($this->rooms[$channel] ?? [] as $cid => $conn) {
            $m = $this->connMeta[$cid] ?? [];
            if (!empty($m['user_id'])) {
                $users[$m['user_id']] = ['id' => $m['user_id'], 'username' => $m['username'], 'display_name' => $m['display_name']];
            }
        }
        $payload = json_encode(['type' => 'online_list', 'users' => array_values($users)]);
        $this->broadcastToRoom($channel, $payload);
    }

    private function getRoomParticipants(string $room, int $excludeId): array {
        $users = [];
        foreach ($this->rooms[$room] ?? [] as $cid => $conn) {
            if ($cid === $excludeId) continue;
            $m = $this->connMeta[$cid] ?? [];
            if (!empty($m['user_id'])) {
                $users[] = ['id' => $m['user_id'], 'username' => $m['username'], 'display_name' => $m['display_name'], 'avatar' => $m['avatar'], 'role' => $m['role']];
            }
        }
        return $users;
    }

    private function fetchUser(int $id): ?array {
        if ($id <= 0) return null;
        try {
            $pdo  = \get_db();
            $stmt = $pdo->prepare('SELECT id, username, display_name, avatar, role FROM users WHERE id = ? AND is_banned = 0');
            $stmt->execute([$id]);
            return $stmt->fetch() ?: null;
        } catch (\Exception $e) {
            return null;
        }
    }

    private function saveMessage(int $user_id, string $channel, string $message): int {
        try {
            $pdo  = \get_db();
            $stmt = $pdo->prepare('INSERT INTO chat_messages (user_id, channel, message) VALUES (?, ?, ?)');
            $stmt->execute([$user_id, $channel, $message]);
            return (int)$pdo->lastInsertId();
        } catch (\Exception $e) {
            return 0;
        }
    }
}
