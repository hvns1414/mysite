<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

require_login();
$user = current_user();
$pdo  = get_db();

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $channel = in_array($_GET['channel'] ?? '', ['instant', 'voice']) ? $_GET['channel'] : 'instant';
    $since   = (int)($_GET['since'] ?? 0);

    $stmt = $pdo->prepare('
        SELECT cm.id, cm.message, cm.created_at, cm.channel,
               u.username, u.display_name, u.avatar, u.role
        FROM chat_messages cm
        JOIN users u ON u.id = cm.user_id
        WHERE cm.channel = ? AND cm.id > ?
        ORDER BY cm.created_at ASC
        LIMIT 50
    ');
    $stmt->execute([$channel, $since]);
    $msgs = $stmt->fetchAll();

    $result = [];
    foreach ($msgs as $m) {
        $result[] = [
            'id'           => (int)$m['id'],
            'username'     => $m['username'],
            'display_name' => $m['display_name'],
            'avatar'       => $m['avatar'],
            'role'         => $m['role'],
            'message'      => $m['message'],
            'time'         => date('H:i', strtotime($m['created_at'])),
            'channel'      => $m['channel'],
        ];
    }
    echo json_encode(['success' => true, 'messages' => $result]);
    exit;
}

if ($method === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'CSRF hatası']);
        exit;
    }

    $message = trim(substr($_POST['message'] ?? '', 0, 1000));
    $channel = in_array($_POST['channel'] ?? '', ['instant', 'voice']) ? $_POST['channel'] : 'instant';

    if (empty($message)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Mesaj boş olamaz']);
        exit;
    }

    $stmt = $pdo->prepare('INSERT INTO chat_messages (user_id, channel, message) VALUES (?, ?, ?)');
    $stmt->execute([$user['id'], $channel, $message]);
    $id = (int)$pdo->lastInsertId();

    echo json_encode([
        'success' => true,
        'msg'     => [
            'id'           => $id,
            'username'     => $user['username'],
            'display_name' => $user['display_name'],
            'avatar'       => $user['avatar'],
            'role'         => $user['role'],
            'message'      => $message,
            'time'         => date('H:i'),
            'channel'      => $channel,
        ],
    ]);
    exit;
}

http_response_code(405);
echo json_encode(['success' => false, 'error' => 'Method not allowed']);
