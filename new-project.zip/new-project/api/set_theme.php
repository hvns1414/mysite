<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

require_login();
$user = current_user();
$pdo  = get_db();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false]);
    exit;
}

if (!verify_csrf($_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'CSRF hatası']);
    exit;
}

$theme = $_POST['theme'] ?? DEFAULT_THEME;
if (!in_array($theme, THEMES, true)) $theme = DEFAULT_THEME;

$pdo->prepare('UPDATE users SET theme_color = ? WHERE id = ?')->execute([$theme, $user['id']]);
$_SESSION['theme'] = $theme;

echo json_encode(['success' => true]);
