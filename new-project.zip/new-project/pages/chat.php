<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/layout.php';

render_header('Anlık Chat');
$user = current_user();
$pdo  = get_db();

$ws_token = bin2hex(random_bytes(16));
$_SESSION['ws_token'] = $ws_token;

$history = $pdo->prepare('
    SELECT cm.*, u.username, u.display_name, u.avatar, u.role
    FROM chat_messages cm
    JOIN users u ON u.id = cm.user_id
    WHERE cm.channel = ?
    ORDER BY cm.created_at DESC
    LIMIT 50
');
$history->execute(['instant']);
$history = array_reverse($history->fetchAll());
?>
<script>
window.CHAT_USER    = <?= json_encode(['id' => $user['id'], 'username' => $user['username'], 'display_name' => $user['display_name'], 'avatar' => $user['avatar'], 'role' => $user['role'], 'ws_token' => $ws_token]) ?>;
window.CHAT_CHANNEL = 'instant';
</script>

<div class="page-header">
    <h1>Anlık Chat</h1>
    <span id="ws-status" class="ws-status ws-connecting">Bağlanıyor...</span>
</div>

<div class="chat-layout">
    <div class="chat-box">
        <div class="chat-messages" id="chat-messages">
            <?php foreach ($history as $msg): ?>
            <div class="chat-message">
                <?php if ($msg['avatar']): ?>
                <img class="chat-msg-avatar" src="<?= APP_URL ?>/public/uploads/<?= e($msg['avatar']) ?>" alt="">
                <?php else: ?>
                <div class="chat-msg-placeholder"><?= e(strtoupper(substr($msg['display_name'] ?: $msg['username'], 0, 1))) ?></div>
                <?php endif; ?>
                <div class="chat-msg-body">
                    <div class="chat-msg-meta">
                        <a href="<?= APP_URL ?>/u/?u=<?= e($msg['username']) ?>" class="chat-msg-user"><?= e($msg['display_name'] ?: $msg['username']) ?></a>
                        <span class="badge badge-<?= e($msg['role']) ?>"><?= e($msg['role']) ?></span>
                        <span class="chat-msg-time"><?= e(date('H:i', strtotime($msg['created_at']))) ?></span>
                    </div>
                    <div class="chat-msg-text"><?= e($msg['message']) ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="chat-input-area">
            <form id="chat-form" style="display:contents">
                <?= csrf_field() ?>
                <input type="text" id="chat-input" class="chat-input"
                       placeholder="Mesajınızı yazın..." maxlength="1000" autocomplete="off">
                <button type="submit" class="btn btn-primary">Gönder</button>
            </form>
        </div>
    </div>

    <div class="chat-sidebar">
        <h3>&#128994; Çevrimiçi</h3>
        <div id="online-list">
            <div class="online-user">
                <div class="online-dot"></div>
                <?= e($user['display_name'] ?: $user['username']) ?>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var box = document.getElementById('chat-messages');
    if (box) box.scrollTop = box.scrollHeight;
});
</script>
<script src="<?= APP_URL ?>/public/js/chat.js"></script>
<?php render_footer(); ?>
