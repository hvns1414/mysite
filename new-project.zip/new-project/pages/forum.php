<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/layout.php';

render_header('Forum');
$user    = current_user();
$pdo     = get_db();
$action  = $_GET['action'] ?? 'list';
$post_id = (int)($_GET['id'] ?? 0);
$is_admin = in_array($user['role'], ['root', 'admin']);
$max_att  = $is_admin ? MAX_FORUM_ATTACHMENT_SIZE_ADMIN : MAX_FORUM_ATTACHMENT_SIZE;

/* ======================================================
   Dosya eki kaydet yardımcısı
   ====================================================== */
function save_attachments(array $files, int $user_id, int $post_id = 0, int $reply_id = 0): array {
    global $pdo, $max_att;
    $errors = [];
    if (empty($files['name'][0])) return $errors;

    $count = min(count($files['name']), MAX_FORUM_ATTACHMENTS_PER_POST);
    for ($i = 0; $i < $count; $i++) {
        if ($files['error'][$i] === UPLOAD_ERR_NO_FILE) continue;
        if ($files['error'][$i] !== UPLOAD_ERR_OK) {
            $errors[] = upload_error_message($files['error'][$i]);
            continue;
        }
        if ($files['size'][$i] > $max_att) {
            $mb = round($max_att / 1024 / 1024);
            $errors[] = "{$files['name'][$i]}: Dosya çok büyük (max {$mb} MB).";
            continue;
        }

        $orig = $files['name'][$i];
        $ext  = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
        $ext  = preg_replace('/[^a-zA-Z0-9]/', '', $ext);
        $filename = 'att_' . bin2hex(random_bytes(16)) . ($ext ? '.' . $ext : '');
        $dest     = UPLOAD_PATH . 'forum/' . $filename;

        if (!move_uploaded_file($files['tmp_name'][$i], $dest)) {
            $errors[] = "{$orig}: Dosya kaydedilemedi.";
            continue;
        }

        $finfo     = new finfo(FILEINFO_MIME_TYPE);
        $mime      = $finfo->file($dest);
        $file_size = filesize($dest);

        $pdo->prepare('INSERT INTO forum_attachments (post_id, reply_id, user_id, filename, original_name, mime_type, file_size) VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([
                $post_id  ?: null,
                $reply_id ?: null,
                $user_id,
                $filename,
                $orig,
                $mime,
                $file_size,
            ]);
    }
    return $errors;
}

function format_filesize(int $bytes): string {
    if ($bytes >= 1073741824) return round($bytes / 1073741824, 2) . ' GB';
    if ($bytes >= 1048576)    return round($bytes / 1048576, 1)    . ' MB';
    if ($bytes >= 1024)       return round($bytes / 1024)          . ' KB';
    return $bytes . ' B';
}

function attachment_icon(string $mime): string {
    if (str_starts_with($mime, 'image/'))  return '🖼️';
    if (str_starts_with($mime, 'video/'))  return '🎬';
    if (str_starts_with($mime, 'audio/'))  return '🎵';
    if ($mime === 'application/pdf')        return '📄';
    if (str_contains($mime, 'zip') || str_contains($mime, 'rar') || str_contains($mime, 'tar')) return '🗜️';
    if (str_contains($mime, 'word') || str_contains($mime, 'document')) return '📝';
    if (str_contains($mime, 'sheet') || str_contains($mime, 'excel'))   return '📊';
    return '📎';
}

function render_attachments(array $atts): string {
    if (empty($atts)) return '';
    $html = '<div class="att-list">';
    foreach ($atts as $a) {
        $url  = APP_URL . '/public/uploads/forum/' . htmlspecialchars($a['filename'], ENT_QUOTES);
        $name = htmlspecialchars($a['original_name'], ENT_QUOTES);
        $size = format_filesize((int)$a['file_size']);
        $icon = attachment_icon($a['mime_type'] ?? '');
        $mime = $a['mime_type'] ?? '';

        if (str_starts_with($mime, 'image/')) {
            $html .= "<div class='att-item att-image'>"
                   . "<a href='{$url}' target='_blank'><img src='{$url}' alt='{$name}' loading='lazy'></a>"
                   . "<div class='att-meta'>{$icon} <span>{$name}</span> <span class='att-size'>{$size}</span></div>"
                   . "</div>";
        } elseif (str_starts_with($mime, 'video/')) {
            $html .= "<div class='att-item att-video'>"
                   . "<video controls preload='metadata'><source src='{$url}' type='{$mime}'></video>"
                   . "<div class='att-meta'>{$icon} <span>{$name}</span> <span class='att-size'>{$size}</span></div>"
                   . "</div>";
        } elseif (str_starts_with($mime, 'audio/')) {
            $html .= "<div class='att-item att-audio'>"
                   . "<audio controls><source src='{$url}' type='{$mime}'></audio>"
                   . "<div class='att-meta'>{$icon} <span>{$name}</span> <span class='att-size'>{$size}</span></div>"
                   . "</div>";
        } else {
            $html .= "<div class='att-item att-file'>"
                   . "<a href='{$url}' target='_blank' download='{$name}' class='att-download'>"
                   . "{$icon} <strong>{$name}</strong> <span class='att-size'>{$size}</span>"
                   . "<span class='att-dl-btn'>İndir ↓</span>"
                   . "</a></div>";
        }
    }
    $html .= '</div>';
    return $html;
}

/* ======================================================
   POST işleme
   ====================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        set_flash('error', 'Güvenlik doğrulaması başarısız.');
        header('Location: ' . $_SERVER['REQUEST_URI']); exit;
    }

    $act = $_POST['post_action'] ?? '';

    if ($act === 'new_post') {
        $title   = trim(substr($_POST['title'] ?? '', 0, 255));
        $content = trim($_POST['content'] ?? '');
        if (empty($title)) {
            set_flash('error', 'Başlık gereklidir.');
        } else {
            $pdo->prepare('INSERT INTO forum_posts (user_id, title, content) VALUES (?, ?, ?)')->execute([$user['id'], $title, $content]);
            $new_id = (int)$pdo->lastInsertId();
            if (!empty($_FILES['attachments']['name'][0])) {
                $errs = save_attachments($_FILES['attachments'], $user['id'], $new_id, 0);
                if ($errs) set_flash('error', implode(' | ', $errs));
            }
            if (!get_flash()) set_flash('success', 'Konu oluşturuldu.');
            header('Location: ' . APP_URL . '/pages/forum.php?action=view&id=' . $new_id); exit;
        }
    }

    if ($act === 'new_reply') {
        $content = trim($_POST['content'] ?? '');
        $pid     = (int)($_POST['post_id'] ?? 0);
        if ($pid) {
            $pdo->prepare('INSERT INTO forum_replies (post_id, user_id, content) VALUES (?, ?, ?)')->execute([$pid, $user['id'], $content ?: '']);
            $rid = (int)$pdo->lastInsertId();
            if (!empty($_FILES['attachments']['name'][0])) {
                $errs = save_attachments($_FILES['attachments'], $user['id'], 0, $rid);
                if ($errs) set_flash('error', implode(' | ', $errs));
            }
            if (!get_flash()) set_flash('success', 'Yanıt eklendi.');
            header('Location: ' . APP_URL . '/pages/forum.php?action=view&id=' . $pid . '#bottom'); exit;
        }
    }

    if ($act === 'delete_post' && $is_admin) {
        $pid = (int)($_POST['post_id'] ?? 0);
        // Dosya eklerini sil
        $atts = $pdo->prepare('SELECT filename FROM forum_attachments WHERE post_id = ?');
        $atts->execute([$pid]);
        foreach ($atts->fetchAll() as $a) { @unlink(UPLOAD_PATH . 'forum/' . $a['filename']); }
        $ratts = $pdo->prepare('SELECT fa.filename FROM forum_attachments fa JOIN forum_replies fr ON fa.reply_id = fr.id WHERE fr.post_id = ?');
        $ratts->execute([$pid]);
        foreach ($ratts->fetchAll() as $a) { @unlink(UPLOAD_PATH . 'forum/' . $a['filename']); }
        $pdo->prepare('DELETE FROM forum_replies WHERE post_id = ?')->execute([$pid]);
        $pdo->prepare('DELETE FROM forum_posts WHERE id = ?')->execute([$pid]);
        set_flash('success', 'Konu silindi.');
        header('Location: ' . APP_URL . '/pages/forum.php'); exit;
    }

    if ($act === 'delete_reply' && $is_admin) {
        $rid = (int)($_POST['reply_id'] ?? 0);
        $pid = (int)($_POST['post_id']  ?? 0);
        $atts = $pdo->prepare('SELECT filename FROM forum_attachments WHERE reply_id = ?');
        $atts->execute([$rid]);
        foreach ($atts->fetchAll() as $a) { @unlink(UPLOAD_PATH . 'forum/' . $a['filename']); }
        $pdo->prepare('DELETE FROM forum_replies WHERE id = ?')->execute([$rid]);
        set_flash('success', 'Yanıt silindi.');
        header('Location: ' . APP_URL . '/pages/forum.php?action=view&id=' . $pid); exit;
    }

    header('Location: ' . $_SERVER['REQUEST_URI']); exit;
}

/* ======================================================
   Liste görünümü
   ====================================================== */
if ($action === 'list') {
    $page  = max(1, (int)($_GET['page'] ?? 1));
    $per   = 15;
    $total = (int)$pdo->query('SELECT COUNT(*) FROM forum_posts')->fetchColumn();
    $pagi  = paginate($total, $per, $page);

    $stmt = $pdo->prepare('
        SELECT fp.*, u.username, u.display_name, u.avatar, u.role,
               (SELECT COUNT(*) FROM forum_replies fr WHERE fr.post_id = fp.id) AS reply_count,
               (SELECT COUNT(*) FROM forum_attachments fa WHERE fa.post_id = fp.id) AS att_count
        FROM forum_posts fp
        JOIN users u ON u.id = fp.user_id
        ORDER BY fp.created_at DESC
        LIMIT ? OFFSET ?
    ');
    $stmt->bindValue(1, $per,            PDO::PARAM_INT);
    $stmt->bindValue(2, $pagi['offset'], PDO::PARAM_INT);
    $stmt->execute();
    $posts = $stmt->fetchAll();
?>
<div class="page-header">
    <h1>📋 Forum</h1>
    <button onclick="document.getElementById('new-post-modal').style.display='flex'" class="btn btn-primary">+ Yeni Konu</button>
</div>

<?= render_flash() ?>

<?php if (empty($posts)): ?>
<div class="card text-center text-muted" style="padding:3rem">
    <div style="font-size:3rem;margin-bottom:.5rem">💬</div>
    Henüz konu yok. İlk konuyu sen aç!
</div>
<?php endif; ?>

<?php foreach ($posts as $post): ?>
<div class="forum-post">
    <div style="display:flex;gap:.75rem;align-items:flex-start">
        <a href="<?= APP_URL ?>/u/?u=<?= e($post['username']) ?>">
            <?php if ($post['avatar']): ?>
            <img src="<?= APP_URL ?>/public/uploads/<?= e($post['avatar']) ?>" style="width:44px;height:44px;border-radius:50%;object-fit:cover;flex-shrink:0">
            <?php else: ?>
            <div style="width:44px;height:44px;border-radius:50%;background:var(--primary);color:var(--primary-t);display:flex;align-items:center;justify-content:center;font-weight:700;flex-shrink:0"><?= e(strtoupper(substr($post['display_name'] ?: $post['username'], 0, 1))) ?></div>
            <?php endif; ?>
        </a>
        <div style="flex:1;min-width:0">
            <div class="forum-post-title">
                <a href="<?= APP_URL ?>/pages/forum.php?action=view&id=<?= (int)$post['id'] ?>"><?= e($post['title']) ?></a>
            </div>
            <div class="forum-post-meta">
                <a href="<?= APP_URL ?>/u/?u=<?= e($post['username']) ?>"><?= e($post['display_name'] ?: $post['username']) ?></a>
                <span class="badge badge-<?= e($post['role']) ?>"><?= e($post['role']) ?></span>
                <span>🕐 <?= e(date('d.m.Y H:i', strtotime($post['created_at']))) ?></span>
                <span>💬 <?= (int)$post['reply_count'] ?> yanıt</span>
                <?php if ($post['att_count'] > 0): ?>
                <span>📎 <?= (int)$post['att_count'] ?> ek</span>
                <?php endif; ?>
            </div>
        </div>
        <?php if ($is_admin): ?>
        <form method="POST" style="flex-shrink:0">
            <?= csrf_field() ?>
            <input type="hidden" name="post_action" value="delete_post">
            <input type="hidden" name="post_id" value="<?= (int)$post['id'] ?>">
            <button type="submit" class="btn btn-danger btn-sm" data-confirm="Konuyu sil?">🗑</button>
        </form>
        <?php endif; ?>
    </div>
</div>
<?php endforeach; ?>

<?php if ($pagi['total_pages'] > 1): ?>
<div class="pagination">
    <?php for ($i = 1; $i <= $pagi['total_pages']; $i++): ?>
    <a href="?page=<?= $i ?>" class="<?= $i === $pagi['current'] ? 'current' : '' ?>"><?= $i ?></a>
    <?php endfor; ?>
</div>
<?php endif; ?>

<!-- Yeni Konu Modal -->
<div id="new-post-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:200;align-items:center;justify-content:center;padding:1rem">
    <div class="card" style="max-width:600px;width:100%;position:relative;max-height:90vh;overflow-y:auto">
        <button onclick="document.getElementById('new-post-modal').style.display='none'" style="position:absolute;top:.75rem;right:.75rem;background:none;border:none;font-size:1.4rem;cursor:pointer;color:var(--text2);line-height:1">✕</button>
        <div class="card-title">Yeni Konu Oluştur</div>
        <form method="POST" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <input type="hidden" name="post_action" value="new_post">
            <div class="form-group">
                <label class="form-label">Başlık *</label>
                <input type="text" name="title" class="form-control" maxlength="255" required placeholder="Konu başlığı...">
            </div>
            <div class="form-group">
                <label class="form-label">İçerik</label>
                <textarea name="content" class="form-control" rows="5" placeholder="Konu içeriği... (opsiyonel)"></textarea>
            </div>
            <div class="form-group">
                <label class="form-label">📎 Dosya Ekle <span class="text-muted" style="font-weight:400">(isteğe bağlı, max <?= MAX_FORUM_ATTACHMENTS_PER_POST ?> dosya)</span></label>
                <input type="file" name="attachments[]" class="form-control" multiple
                       accept="*/*">
                <div class="text-sm text-muted mt-1">
                    Her türlü dosya desteklenir — max <?= round($max_att/1024/1024) ?>MB per dosya
                </div>
                <div id="file-preview-new" class="file-preview-area"></div>
            </div>
            <div style="display:flex;gap:.5rem;justify-content:flex-end">
                <button type="button" onclick="document.getElementById('new-post-modal').style.display='none'" class="btn btn-ghost">İptal</button>
                <button type="submit" class="btn btn-primary">📤 Yayınla</button>
            </div>
        </form>
    </div>
</div>

<?php } /* end list */

/* ======================================================
   Konu görüntüle
   ====================================================== */
if ($action === 'view' && $post_id) {
    $post = $pdo->prepare('SELECT fp.*, u.username, u.display_name, u.avatar, u.role FROM forum_posts fp JOIN users u ON u.id = fp.user_id WHERE fp.id = ?');
    $post->execute([$post_id]);
    $post = $post->fetch();

    if (!$post) { echo '<div class="alert alert-error">Konu bulunamadı.</div>'; }
    else {
        $replies = $pdo->prepare('SELECT fr.*, u.username, u.display_name, u.avatar, u.role FROM forum_replies fr JOIN users u ON u.id = fr.user_id WHERE fr.post_id = ? ORDER BY fr.created_at ASC');
        $replies->execute([$post_id]);
        $replies = $replies->fetchAll();

        // Post ekleri
        $pa = $pdo->prepare('SELECT * FROM forum_attachments WHERE post_id = ?');
        $pa->execute([$post_id]);
        $post_atts = $pa->fetchAll();

        // Reply ekleri
        $reply_ids = array_column($replies, 'id');
        $reply_atts = [];
        if ($reply_ids) {
            $in  = implode(',', array_fill(0, count($reply_ids), '?'));
            $ra  = $pdo->prepare("SELECT * FROM forum_attachments WHERE reply_id IN ($in)");
            $ra->execute($reply_ids);
            foreach ($ra->fetchAll() as $a) {
                $reply_atts[(int)$a['reply_id']][] = $a;
            }
        }
?>
<div class="page-header">
    <h1><?= e($post['title']) ?></h1>
    <a href="<?= APP_URL ?>/pages/forum.php" class="btn btn-ghost btn-sm">← Foruma Dön</a>
</div>

<?= render_flash() ?>

<!-- Ana post -->
<div class="forum-view-post card mb-2">
    <div class="forum-author">
        <a href="<?= APP_URL ?>/u/?u=<?= e($post['username']) ?>">
            <?php if ($post['avatar']): ?>
            <img src="<?= APP_URL ?>/public/uploads/<?= e($post['avatar']) ?>" class="forum-author-avatar" alt="">
            <?php else: ?>
            <div class="forum-author-placeholder"><?= e(strtoupper(substr($post['display_name'] ?: $post['username'], 0, 1))) ?></div>
            <?php endif; ?>
        </a>
        <div>
            <a href="<?= APP_URL ?>/u/?u=<?= e($post['username']) ?>" class="forum-author-name"><?= e($post['display_name'] ?: $post['username']) ?></a>
            <span class="badge badge-<?= e($post['role']) ?>"><?= e($post['role']) ?></span>
            <div class="text-sm text-muted"><?= e(date('d.m.Y H:i', strtotime($post['created_at']))) ?></div>
        </div>
        <?php if ($is_admin): ?>
        <form method="POST" style="margin-left:auto">
            <?= csrf_field() ?>
            <input type="hidden" name="post_action" value="delete_post">
            <input type="hidden" name="post_id" value="<?= (int)$post_id ?>">
            <button type="submit" class="btn btn-danger btn-sm" data-confirm="Konuyu sil?">🗑 Sil</button>
        </form>
        <?php endif; ?>
    </div>
    <?php if ($post['content']): ?>
    <div class="forum-content"><?= nl2br(e($post['content'])) ?></div>
    <?php endif; ?>
    <?= render_attachments($post_atts) ?>
</div>

<!-- Yanıtlar -->
<?php if (!empty($replies)): ?>
<div class="forum-reply-count"><?= count($replies) ?> Yanıt</div>
<?php foreach ($replies as $reply): ?>
<div class="forum-reply-item card mb-1">
    <div class="forum-author">
        <a href="<?= APP_URL ?>/u/?u=<?= e($reply['username']) ?>">
            <?php if ($reply['avatar']): ?>
            <img src="<?= APP_URL ?>/public/uploads/<?= e($reply['avatar']) ?>" class="forum-author-avatar" alt="">
            <?php else: ?>
            <div class="forum-author-placeholder"><?= e(strtoupper(substr($reply['display_name'] ?: $reply['username'], 0, 1))) ?></div>
            <?php endif; ?>
        </a>
        <div>
            <a href="<?= APP_URL ?>/u/?u=<?= e($reply['username']) ?>" class="forum-author-name"><?= e($reply['display_name'] ?: $reply['username']) ?></a>
            <span class="badge badge-<?= e($reply['role']) ?>"><?= e($reply['role']) ?></span>
            <div class="text-sm text-muted"><?= e(date('d.m.Y H:i', strtotime($reply['created_at']))) ?></div>
        </div>
        <?php if ($is_admin): ?>
        <form method="POST" style="margin-left:auto">
            <?= csrf_field() ?>
            <input type="hidden" name="post_action" value="delete_reply">
            <input type="hidden" name="reply_id" value="<?= (int)$reply['id'] ?>">
            <input type="hidden" name="post_id"  value="<?= (int)$post_id ?>">
            <button type="submit" class="btn btn-danger btn-sm" data-confirm="Yanıtı sil?">🗑</button>
        </form>
        <?php endif; ?>
    </div>
    <?php if ($reply['content']): ?>
    <div class="forum-content"><?= nl2br(e($reply['content'])) ?></div>
    <?php endif; ?>
    <?= render_attachments($reply_atts[(int)$reply['id']] ?? []) ?>
</div>
<?php endforeach; ?>
<?php endif; ?>

<!-- Yanıt formu -->
<div id="bottom" class="card mt-2">
    <div class="card-title">💬 Yanıt Yaz</div>
    <form method="POST" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <input type="hidden" name="post_action" value="new_reply">
        <input type="hidden" name="post_id" value="<?= (int)$post_id ?>">
        <div class="form-group">
            <textarea name="content" class="form-control" rows="4" placeholder="Yanıtınızı yazın..."></textarea>
        </div>
        <div class="form-group">
            <label class="form-label">📎 Dosya Ekle <span class="text-muted" style="font-weight:400">(isteğe bağlı)</span></label>
            <input type="file" name="attachments[]" class="form-control" multiple accept="*/*">
            <div class="text-sm text-muted mt-1">Her türlü dosya — max <?= round($max_att/1024/1024) ?>MB per dosya</div>
            <div id="file-preview-reply" class="file-preview-area"></div>
        </div>
        <button type="submit" class="btn btn-primary">📤 Yanıtla</button>
    </form>
</div>
<?php }} /* end view */
render_footer(); ?>
<script>
// Dosya seçim önizleme
document.querySelectorAll('input[type="file"][multiple]').forEach(function(inp){
    var previewId = inp.closest('form').id === '' 
        ? (inp.closest('[id]') ? inp.closest('[id]').querySelector('.file-preview-area') : null)
        : null;
    var preview = inp.parentElement.querySelector('.file-preview-area');
    if (!preview) return;
    inp.addEventListener('change', function(){
        preview.innerHTML = '';
        Array.from(this.files).forEach(function(f){
            var icon = f.type.startsWith('image/') ? '🖼️' : f.type.startsWith('video/') ? '🎬' : f.type.startsWith('audio/') ? '🎵' : '📎';
            var size = f.size > 1048576 ? (f.size/1048576).toFixed(1)+' MB' : Math.round(f.size/1024)+' KB';
            var d = document.createElement('div');
            d.className = 'file-chip';
            d.innerHTML = icon + ' <span>' + f.name.substring(0,40) + '</span> <small>' + size + '</small>';
            preview.appendChild(d);
        });
    });
});
</script>
