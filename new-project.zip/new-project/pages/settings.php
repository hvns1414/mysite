<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/layout.php';

render_header('Ayarlar');
$user = current_user();
$pdo  = get_db();

// Rol bazlı limitler
$is_admin   = in_array($user['role'], ['root', 'admin']);
$max_avatar = $is_admin ? MAX_AVATAR_SIZE_ADMIN    : MAX_AVATAR_SIZE;
$max_img    = $is_admin ? MAX_BG_IMAGE_SIZE_ADMIN  : MAX_BG_IMAGE_SIZE;
$max_video  = $is_admin ? MAX_BG_VIDEO_SIZE_ADMIN  : MAX_BG_VIDEO_SIZE;
$max_bg     = max($max_img, $max_video);

$tab    = $_GET['tab'] ?? 'profile';
$error  = '';
$success= '';

/* ===== POST işleme ===== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Güvenlik doğrulaması başarısız.';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'profile') {
            $display_name = trim(substr($_POST['display_name'] ?? '', 0, 100));
            $pdo->prepare('UPDATE users SET display_name = ? WHERE id = ?')->execute([$display_name, $user['id']]);

            // Avatar yükleme
            if (!empty($_FILES['avatar']['name']) && $_FILES['avatar']['error'] !== UPLOAD_ERR_NO_FILE) {
                $check = validate_upload($_FILES['avatar'], ALLOWED_AVATAR_TYPES, $max_avatar);
                if (!$check['valid']) { $error = $check['message']; }
                else {
                    if ($user['avatar']) delete_upload($user['avatar']);
                    $path = save_upload($_FILES['avatar'], 'avatars', 'av_');
                    $pdo->prepare('UPDATE users SET avatar = ? WHERE id = ?')->execute([$path, $user['id']]);
                }
            }

            // Arka plan yükleme
            if (!empty($_FILES['background']['name']) && $_FILES['background']['error'] !== UPLOAD_ERR_NO_FILE) {
                $allowed = array_merge(ALLOWED_BG_IMAGE_TYPES, ALLOWED_BG_VIDEO_TYPES);
                $check   = validate_upload($_FILES['background'], $allowed, $max_bg);
                if (!$check['valid']) { $error = $check['message']; }
                else {
                    if ($user['background_url']) delete_upload($user['background_url']);
                    $bg_type = str_starts_with($check['mime'], 'video/') ? 'video' : 'image';
                    $path    = save_upload($_FILES['background'], 'backgrounds', 'bg_');
                    $pdo->prepare('UPDATE users SET background_url = ?, background_type = ? WHERE id = ?')->execute([$path, $bg_type, $user['id']]);
                }
            }

            if (!$error) $success = 'Profil güncellendi.';
            $tab = 'profile';

        } elseif ($action === 'theme') {
            $theme = $_POST['theme'] ?? DEFAULT_THEME;
            if (!in_array($theme, THEMES, true)) $theme = DEFAULT_THEME;
            $pdo->prepare('UPDATE users SET theme_color = ? WHERE id = ?')->execute([$theme, $user['id']]);
            $_SESSION['theme'] = $theme;
            $success = 'Tema güncellendi.';
            $tab = 'theme';

        } elseif ($action === 'password') {
            $old  = $_POST['old_password']     ?? '';
            $new1 = $_POST['new_password']     ?? '';
            $new2 = $_POST['confirm_password'] ?? '';
            if (!password_verify($old, $user['password'])) {
                $error = 'Mevcut şifre hatalı.';
            } elseif ($new1 !== $new2) {
                $error = 'Yeni şifreler eşleşmiyor.';
            } else {
                $check = validate_password_strength($new1);
                if (!$check['valid']) { $error = $check['message']; }
                else {
                    $hash = password_hash($new1, PASSWORD_BCRYPT);
                    $pdo->prepare('UPDATE users SET password = ? WHERE id = ?')->execute([$hash, $user['id']]);
                    $success = 'Şifre güncellendi.';
                }
            }
            $tab = 'password';
        }

        // Kullanıcıyı yenile
        $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
        $stmt->execute([$user['id']]);
        $user = $stmt->fetch();
    }
}

$theme = $user['theme_color'] ?? DEFAULT_THEME;
?>
<div class="page-header"><h1>Ayarlar</h1></div>

<div class="settings-grid">
    <nav class="settings-nav">
        <a href="?tab=profile"  class="<?= $tab === 'profile'  ? 'active' : '' ?>">&#128100; Profil</a>
        <a href="?tab=theme"    class="<?= $tab === 'theme'    ? 'active' : '' ?>">&#127775; Tema</a>
        <a href="?tab=password" class="<?= $tab === 'password' ? 'active' : '' ?>">&#128274; Şifre</a>
    </nav>

    <div>
        <?php if ($error):   ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
        <?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>

        <?php if ($tab === 'profile'): ?>
        <div class="card">
            <div class="card-title">Profil Bilgileri</div>
            <?php if ($is_admin): ?>
            <div class="alert alert-info" style="margin-bottom:1rem">Admin: Fotoğraf max <?= round($max_avatar/1024/1024) ?>MB | Arka plan resim max <?= round($max_img/1024/1024/1024, 1) ?>GB | Video max <?= round($max_video/1024/1024/1024, 1) ?>GB</div>
            <?php endif; ?>
            <form method="POST" enctype="multipart/form-data">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="profile">

                <div class="form-group">
                    <label class="form-label">Görünen Ad</label>
                    <input type="text" name="display_name" class="form-control"
                           value="<?= e($user['display_name'] ?? '') ?>" maxlength="100">
                </div>

                <div class="form-group">
                    <label class="form-label">Profil Fotoğrafı</label>
                    <div class="avatar-preview-wrap">
                        <?php if ($user['avatar']): ?>
                        <img id="avatar_preview_img" src="<?= APP_URL ?>/public/uploads/<?= e($user['avatar']) ?>" class="avatar-preview" alt="avatar">
                        <?php else: ?>
                        <div class="avatar-preview-placeholder" id="avatar_preview_img">&#128100;</div>
                        <?php endif; ?>
                        <div>
                            <input type="file" id="avatar_input" name="avatar"
                                   accept="image/jpeg,image/jpg,image/png,image/gif,image/webp,image/bmp,image/tiff"
                                   class="form-control" style="max-width:300px">
                            <div class="text-sm text-muted mt-1">
                                JPG, PNG, GIF, WEBP, BMP, TIFF — max <?= round($max_avatar/1024/1024) ?>MB
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Profil Arka Planı (Resim veya Video)</label>
                    <div id="bg_preview" style="margin-bottom:.5rem">
                        <?php if ($user['background_url']): ?>
                            <?php if ($user['background_type'] === 'video'): ?>
                            <video src="<?= APP_URL ?>/public/uploads/<?= e($user['background_url']) ?>" autoplay muted loop style="max-width:100%;max-height:150px;border-radius:8px"></video>
                            <?php else: ?>
                            <img src="<?= APP_URL ?>/public/uploads/<?= e($user['background_url']) ?>" style="max-width:100%;max-height:150px;border-radius:8px" alt="bg">
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <input type="file" id="bg_input" name="background"
                           accept="image/jpeg,image/jpg,image/png,image/webp,image/gif,image/bmp,video/mp4,video/webm,video/ogg,video/avi,video/quicktime,video/x-ms-wmv,video/mpeg,video/3gpp,video/x-matroska"
                           class="form-control">
                    <div class="text-sm text-muted mt-1">
                        Resim: JPG, PNG, WEBP, GIF, BMP — max <?= round($max_img/1024/1024) ?>MB<br>
                        Video: MP4, WEBM, AVI, MOV, MKV, WMV, OGG — max <?= round($max_video/1024/1024/1024, 1) ?>GB
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">Kaydet</button>
            </form>
        </div>

        <?php elseif ($tab === 'theme'): ?>
        <div class="card">
            <div class="card-title">Tema Rengi</div>
            <form method="POST">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="theme">
                <input type="hidden" name="theme" id="theme_input" value="<?= e($theme) ?>">
                <div class="form-group">
                    <label class="form-label">Renk Seç</label>
                    <div class="theme-picker">
                        <?php foreach (THEMES as $t): ?>
                        <div class="theme-swatch <?= $theme === $t ? 'selected' : '' ?>"
                             data-theme="<?= e($t) ?>"
                             title="<?= e(ucfirst($t)) ?>"
                             onclick="document.getElementById('theme_input').value='<?= e($t) ?>';document.querySelectorAll('.theme-swatch').forEach(function(s){s.classList.toggle('selected',s.dataset.theme==='<?= e($t) ?>')});"></div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div style="display:flex;gap:.5rem;margin-top:1rem;flex-wrap:wrap">
                    <?php foreach (THEMES as $t): ?>
                    <span style="font-size:.8rem;color:var(--text2)"><?= e(ucfirst($t)) ?></span>
                    <?php endforeach; ?>
                </div>
                <button type="submit" class="btn btn-primary mt-2">Kaydet</button>
            </form>
        </div>

        <?php elseif ($tab === 'password'): ?>
        <div class="card">
            <div class="card-title">Şifre Değiştir</div>
            <form method="POST">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="password">
                <div class="form-group">
                    <label class="form-label" for="old_password">Mevcut Şifre</label>
                    <input type="password" id="old_password" name="old_password" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="new_password">Yeni Şifre</label>
                    <input type="password" id="new_password" name="new_password" class="form-control" required minlength="8">
                </div>
                <div class="form-group">
                    <label class="form-label" for="confirm_password">Yeni Şifre Tekrar</label>
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary">Şifreyi Güncelle</button>
            </form>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php render_footer(); ?>
