<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

start_secure_session();
if (is_logged_in()) { header('Location: ' . APP_URL . '/pages/dashboard.php'); exit; }

$token   = trim($_GET['token'] ?? '');
$message = '';
$type    = '';
$valid   = false;

if (empty($token)) {
    header('Location: ' . APP_URL . '/pages/forgot_password.php');
    exit;
}

$pdo  = get_db();
$stmt = $pdo->prepare('SELECT prt.*, u.username FROM password_reset_tokens prt JOIN users u ON u.id = prt.user_id WHERE prt.token = ? AND prt.used = 0 AND prt.expires_at > NOW()');
$stmt->execute([$token]);
$record = $stmt->fetch();

if (!$record) {
    $message = 'Bu link geçersiz veya süresi dolmuş.';
    $type    = 'error';
} else {
    $valid = true;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $valid) {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $message = 'Güvenlik doğrulaması başarısız.';
        $type    = 'error';
    } else {
        $new_pass  = $_POST['new_password']     ?? '';
        $conf_pass = $_POST['confirm_password'] ?? '';

        $check = validate_password_strength($new_pass);
        if (!$check['valid']) {
            $message = $check['message'];
            $type    = 'error';
        } elseif ($new_pass !== $conf_pass) {
            $message = 'Şifreler eşleşmiyor.';
            $type    = 'error';
        } else {
            $hash = password_hash($new_pass, PASSWORD_BCRYPT);
            $pdo->prepare('UPDATE users SET password = ? WHERE id = ?')->execute([$hash, $record['user_id']]);
            $pdo->prepare('UPDATE password_reset_tokens SET used = 1 WHERE token = ?')->execute([$token]);
            $message = 'Şifreniz başarıyla güncellendi. <a href="' . APP_URL . '/pages/login.php">Giriş yapın</a>';
            $type    = 'success';
            $valid   = false;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr" data-theme="white">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şifre Sıfırla — <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= APP_URL ?>/public/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="theme-white">
<div class="login-page">
    <div class="login-card">
        <div class="login-logo"><?= e(APP_NAME) ?></div>
        <h2 style="text-align:center;font-size:1.1rem;margin-bottom:1.5rem;color:var(--text2)">Şifre Sıfırla</h2>

        <?php if ($message): ?>
        <div class="alert alert-<?= $type ?>"><?= $message ?></div>
        <?php endif; ?>

        <?php if ($valid): ?>
        <form method="POST" action="">
            <?= csrf_field() ?>
            <div class="form-group">
                <label class="form-label" for="new_password">Yeni Şifre</label>
                <input type="password" id="new_password" name="new_password" class="form-control" required minlength="8">
            </div>
            <div class="form-group">
                <label class="form-label" for="confirm_password">Şifre Tekrar</label>
                <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary w-full">Şifreyi Güncelle</button>
        </form>
        <?php endif; ?>

        <div class="mt-2 text-center">
            <a href="<?= APP_URL ?>/pages/login.php" class="text-sm text-muted">Giriş Yap</a>
        </div>
    </div>
</div>
<script src="<?= APP_URL ?>/public/js/main.js"></script>
</body>
</html>
