<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

start_secure_session();
if (is_logged_in()) { header('Location: ' . APP_URL . '/pages/dashboard.php'); exit; }

$message = '';
$type    = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $message = 'Güvenlik doğrulaması başarısız.';
        $type    = 'error';
    } else {
        $username = trim($_POST['username'] ?? '');
        if (empty($username)) {
            $message = 'Kullanıcı adı gereklidir.';
            $type    = 'error';
        } else {
            $pdo  = get_db();
            $stmt = $pdo->prepare('SELECT id FROM users WHERE username = ? AND is_banned = 0');
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user) {
                $pdo->prepare('DELETE FROM password_reset_tokens WHERE user_id = ? AND used = 0')->execute([$user['id']]);
                $token   = bin2hex(random_bytes(32));
                $expires = date('Y-m-d H:i:s', strtotime('+' . RESET_TOKEN_EXPIRY_HOURS . ' hour'));
                $pdo->prepare('INSERT INTO password_reset_tokens (user_id, token, expires_at) VALUES (?, ?, ?)')->execute([$user['id'], $token, $expires]);
                $reset_url = APP_URL . '/pages/reset_password.php?token=' . $token;
                $message = 'Şifre sıfırlama linkiniz: <a href="' . e($reset_url) . '">' . e($reset_url) . '</a>';
            } else {
                $message = 'Kullanıcı bulunamadı veya hesap banlı.';
                $type    = 'error';
            }

            if (!$type) $type = 'success';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr" data-theme="white">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şifremi Unuttum — <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= APP_URL ?>/public/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="theme-white">
<div class="login-page">
    <div class="login-card">
        <div class="login-logo"><?= e(APP_NAME) ?></div>
        <h2 style="text-align:center;font-size:1.1rem;margin-bottom:1.5rem;color:var(--text2)">Şifremi Unuttum</h2>

        <?php if ($message): ?>
        <div class="alert alert-<?= $type ?>"><?= $message ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <?= csrf_field() ?>
            <div class="form-group">
                <label class="form-label" for="username">Kullanıcı Adı</label>
                <input type="text" id="username" name="username" class="form-control"
                       value="<?= e($_POST['username'] ?? '') ?>" autofocus required>
            </div>
            <button type="submit" class="btn btn-primary w-full">Sıfırlama Linki Al</button>
        </form>

        <div class="mt-2 text-center">
            <a href="<?= APP_URL ?>/pages/login.php" class="text-sm text-muted">Giriş Yap</a>
        </div>
    </div>
</div>
<script src="<?= APP_URL ?>/public/js/main.js"></script>
</body>
</html>
