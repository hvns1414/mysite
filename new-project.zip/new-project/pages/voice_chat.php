<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/layout.php';

render_header('Sesli Chat');
$user     = current_user();
$ws_token = bin2hex(random_bytes(16));
$_SESSION['ws_token'] = $ws_token;
?>
<script>
window.VOICE_USER = <?= json_encode(['id' => $user['id'], 'username' => $user['username'], 'display_name' => $user['display_name'], 'avatar' => $user['avatar'], 'role' => $user['role'], 'ws_token' => $ws_token]) ?>;
</script>

<div class="page-header">
    <h1>Sesli Chat &amp; Ekran Paylaşımı</h1>
    <span id="ws-status" class="ws-status ws-connecting">Bağlanıyor...</span>
</div>

<div class="voice-layout">
    <!-- Ekran paylaşımı alanı -->
    <div class="screen-share-area" id="screen-share-area"></div>

    <!-- Katılımcılar -->
    <div class="card">
        <div class="card-title">Katılımcılar</div>
        <div class="voice-participants" id="participants">
            <!-- JS ile doldurulur -->
        </div>
    </div>

    <!-- Kontroller -->
    <div class="voice-controls">
        <button class="voice-btn btn-primary" id="btn-join" title="Odaya Katıl" style="width:auto;padding:0 1.2rem;border-radius:8px;background:var(--primary);color:var(--primary-t)">
            &#127908; Odaya Katıl
        </button>
        <button class="voice-btn danger" id="btn-leave" title="Odadan Ayrıl" style="display:none">&#128683;</button>
        <button class="voice-btn" id="btn-mute" title="Sesi Kapat" style="display:none">&#127908;</button>
        <button class="voice-btn" id="btn-screen" title="Ekran Paylaş" style="display:none">&#128250;</button>
    </div>

    <div class="card text-sm text-muted">
        <p><strong>Nasıl kullanılır:</strong> "Odaya Katıl" butonuna tıklayın ve tarayıcı mikrofon iznini onaylayın. Ekran paylaşımı için &#128250; ikonuna tıklayın.</p>
        <p class="mt-1">WebRTC teknolojisi kullanılmaktadır. Sesli görüşme uçtan uca P2P olarak gerçekleşir.</p>
    </div>
</div>

<script src="<?= APP_URL ?>/public/js/voice.js"></script>
<?php render_footer(); ?>
