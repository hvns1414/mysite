<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/layout.php';

render_header('Dashboard');
$user = current_user();
$pdo  = get_db();

$total_users   = $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
$total_posts   = $pdo->query('SELECT COUNT(*) FROM forum_posts')->fetchColumn();
$total_msgs    = $pdo->query('SELECT COUNT(*) FROM chat_messages')->fetchColumn();
$banned_count  = $pdo->query('SELECT COUNT(*) FROM users WHERE is_banned = 1')->fetchColumn();

$recent_users = $pdo->query('SELECT username, display_name, role, created_at FROM users ORDER BY created_at DESC LIMIT 5')->fetchAll();
?>
<div class="page-header">
    <h1>Hoş geldin, <?= e($user['display_name'] ?: $user['username']) ?></h1>
    <a href="<?= APP_URL ?>/u/?u=<?= e($user['username']) ?>" class="btn btn-ghost btn-sm">Profilim</a>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-num"><?= (int)$total_users ?></div>
        <div class="stat-label">Toplam Kullanıcı</div>
    </div>
    <div class="stat-card">
        <div class="stat-num"><?= (int)$total_posts ?></div>
        <div class="stat-label">Forum Konusu</div>
    </div>
    <div class="stat-card">
        <div class="stat-num"><?= (int)$total_msgs ?></div>
        <div class="stat-label">Mesaj</div>
    </div>
    <div class="stat-card">
        <div class="stat-num"><?= (int)$banned_count ?></div>
        <div class="stat-label">Banlı Kullanıcı</div>
    </div>
</div>

<div class="grid-2">
    <div class="card">
        <div class="card-title">Hızlı Erişim</div>
        <div style="display:flex;flex-direction:column;gap:.5rem">
            <a href="<?= APP_URL ?>/pages/forum.php"      class="btn btn-ghost">Forum</a>
            <a href="<?= APP_URL ?>/pages/chat.php"       class="btn btn-ghost">Anlık Chat</a>
            <a href="<?= APP_URL ?>/pages/voice_chat.php" class="btn btn-ghost">Sesli Chat</a>
            <a href="<?= APP_URL ?>/pages/settings.php"   class="btn btn-ghost">Ayarlar</a>
            <?php if (in_array($user['role'], ['root', 'admin'])): ?>
            <a href="<?= APP_URL ?>/admin/" class="btn btn-primary">Admin Paneli</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="card">
        <div class="card-title">Son Katılanlar</div>
        <?php foreach ($recent_users as $ru): ?>
        <div style="display:flex;align-items:center;justify-content:space-between;padding:.4rem 0;border-bottom:1px solid var(--border)">
            <a href="<?= APP_URL ?>/u/?u=<?= e($ru['username']) ?>" style="font-size:.9rem;font-weight:500">
                <?= e($ru['display_name'] ?: $ru['username']) ?>
            </a>
            <span class="badge badge-<?= e($ru['role']) ?>"><?= e($ru['role']) ?></span>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php render_footer(); ?>
