<?php
/**
 * Kurulum scripti — tek seferlik çalıştırın.
 * Tabloları oluşturur ve root kullanıcısını ekler.
 * Çalıştırdıktan sonra bu dosyayı silin veya .htaccess ile koruyun.
 */

define('SETUP_KEY', 'kurulum2026');

if (($_GET['key'] ?? '') !== SETUP_KEY) {
    http_response_code(403);
    die('Erişim reddedildi. URL\'ye ?key=kurulum2026 ekleyin.');
}

require_once __DIR__ . '/../config/database.php';

$pdo = null;

// Önce DB'ye bağlan (DB olmadan)
$dsn = 'mysql:host=localhost;charset=utf8mb4';
try {
    $pdo = new PDO($dsn, 'root', '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);
    $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    $pdo->exec('USE `' . DB_NAME . '`');
} catch (PDOException $e) {
    die('Veritabanı oluşturulamadı: ' . $e->getMessage());
}

$sql = "
CREATE TABLE IF NOT EXISTS `users` (
    `id`              INT          UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `username`        VARCHAR(50)  NOT NULL UNIQUE,
    `email`           VARCHAR(100) NOT NULL UNIQUE,
    `password`        VARCHAR(255) NOT NULL,
    `display_name`    VARCHAR(100) DEFAULT NULL,
    `role`            ENUM('root','admin','usr') NOT NULL DEFAULT 'usr',
    `avatar`          VARCHAR(255) DEFAULT NULL,
    `background_type` ENUM('image','video') DEFAULT 'image',
    `background_url`  VARCHAR(255) DEFAULT NULL,
    `theme_color`     ENUM('white','red','blue','black') NOT NULL DEFAULT 'white',
    `is_banned`       TINYINT(1) NOT NULL DEFAULT 0,
    `created_by`      INT UNSIGNED DEFAULT NULL,
    `created_at`      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_username` (`username`),
    INDEX `idx_role` (`role`),
    INDEX `idx_banned` (`is_banned`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `login_attempts` (
    `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `ip`           VARCHAR(45) NOT NULL,
    `attempted_at` DATETIME    NOT NULL,
    INDEX `idx_ip_time` (`ip`, `attempted_at`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `chat_messages` (
    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`    INT UNSIGNED NOT NULL,
    `channel`    ENUM('instant','voice') NOT NULL DEFAULT 'instant',
    `message`    TEXT NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_channel_time` (`channel`, `created_at`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `forum_posts` (
    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`    INT UNSIGNED NOT NULL,
    `title`      VARCHAR(255) NOT NULL,
    `content`    TEXT NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_created` (`created_at`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `forum_replies` (
    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `post_id`    INT UNSIGNED NOT NULL,
    `user_id`    INT UNSIGNED NOT NULL,
    `content`    TEXT NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_post` (`post_id`),
    FOREIGN KEY (`post_id`)  REFERENCES `forum_posts`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`)  REFERENCES `users`(`id`)       ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`    INT UNSIGNED NOT NULL,
    `token`      VARCHAR(64)  NOT NULL UNIQUE,
    `expires_at` DATETIME     NOT NULL,
    `used`       TINYINT(1)   NOT NULL DEFAULT 0,
    INDEX `idx_token` (`token`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;
";

foreach (array_filter(array_map('trim', explode(';', $sql))) as $q) {
    if (!empty($q)) {
        try {
            $pdo->exec($q);
        } catch (PDOException $e) {
            echo '<p style="color:red">Hata: ' . htmlspecialchars($e->getMessage()) . '</p>';
        }
    }
}

// Root kullanıcısı
$stmt = $pdo->prepare('SELECT id FROM users WHERE username = ?');
$stmt->execute(['root']);
if (!$stmt->fetch()) {
    $hash = password_hash('toor', PASSWORD_BCRYPT);
    $pdo->prepare('INSERT INTO users (username, email, password, display_name, role, theme_color) VALUES (?, ?, ?, ?, ?, ?)')
        ->execute(['root', 'root@localhost', $hash, 'Root', 'root', 'white']);
    echo '<p style="color:green">Root kullanıcısı oluşturuldu (root / toor)</p>';
} else {
    echo '<p style="color:orange">Root kullanıcısı zaten mevcut.</p>';
}

echo '<p style="color:green"><strong>Kurulum tamamlandı!</strong></p>';
echo '<p>Bu dosyayı silin veya yeniden erişimi engelleyin.</p>';
echo '<p><a href="' . (defined('APP_URL') ? '' : '') . '/pages/login.php">Giriş Yap</a></p>';
