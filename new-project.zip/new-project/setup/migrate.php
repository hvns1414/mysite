<?php
/**
 * Migration: forum_attachments tablosunu ekle
 * Çalıştır: php setup/migrate.php
 */
require_once __DIR__ . '/../config/database.php';

$pdo = get_db();

$sql = "
CREATE TABLE IF NOT EXISTS `forum_attachments` (
    `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `post_id`       INT UNSIGNED DEFAULT NULL,
    `reply_id`      INT UNSIGNED DEFAULT NULL,
    `user_id`       INT UNSIGNED NOT NULL,
    `filename`      VARCHAR(255) NOT NULL,
    `original_name` VARCHAR(255) NOT NULL,
    `mime_type`     VARCHAR(100) DEFAULT NULL,
    `file_size`     BIGINT UNSIGNED NOT NULL DEFAULT 0,
    `created_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_post`  (`post_id`),
    INDEX `idx_reply` (`reply_id`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;
";

try {
    $pdo->exec($sql);
    echo "forum_attachments tablosu oluşturuldu (veya zaten vardı).\n";
} catch (PDOException $e) {
    echo "Hata: " . $e->getMessage() . "\n";
}
