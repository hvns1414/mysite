<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

start_secure_session();

$username = trim($_GET['u'] ?? '');
if (empty($username)) {
    header('Location: ' . APP_URL . '/');
    exit;
}

$pdo  = get_db();
$stmt = $pdo->prepare('SELECT * FROM users WHERE username = ? AND is_banned = 0');
$stmt->execute([$username]);
$profile = $stmt->fetch();

if (!$profile) {
    http_response_code(404);
    die('<!DOCTYPE html><html><body style="background:#111;color:#fff;display:flex;align-items:center;justify-content:center;height:100vh;font-family:sans-serif"><div style="text-align:center"><h1>404</h1><p>Kullanıcı bulunamadı.</p><a href="' . APP_URL . '/" style="color:#4af">Ana Sayfa</a></div></body></html>');
}

$is_own = is_logged_in() && ($_SESSION['user_id'] ?? 0) === (int)$profile['id'];

$post_count  = (int)$pdo->prepare('SELECT COUNT(*) FROM forum_posts WHERE user_id = ?')->execute([$profile['id']]) ? $pdo->query('SELECT COUNT(*) FROM forum_posts WHERE user_id = ' . (int)$profile['id'])->fetchColumn() : 0;

$stmt2 = $pdo->prepare('SELECT COUNT(*) FROM forum_posts WHERE user_id = ?');
$stmt2->execute([$profile['id']]);
$post_count = (int)$stmt2->fetchColumn();

$joined = date('d.m.Y', strtotime($profile['created_at']));
?>
<!DOCTYPE html>
<html lang="tr" data-theme="<?= e($profile['theme_color'] ?? 'white') ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($profile['display_name'] ?: $profile['username']) ?> — <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= APP_URL ?>/public/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { overflow: hidden; }
        .profile-page { height: 100vh; }
    </style>
</head>
<body class="theme-<?= e($profile['theme_color'] ?? 'white') ?>">

<div class="profile-page">
    <!-- Arka plan -->
    <div class="profile-bg">
        <?php if ($profile['background_url']): ?>
            <?php if ($profile['background_type'] === 'video'): ?>
            <video src="<?= APP_URL ?>/public/uploads/<?= e($profile['background_url']) ?>" autoplay muted loop playsinline></video>
            <?php else: ?>
            <img src="<?= APP_URL ?>/public/uploads/<?= e($profile['background_url']) ?>" alt="bg">
            <?php endif; ?>
        <?php else: ?>
        <div style="width:100%;height:100%;background:linear-gradient(135deg,#1a1a2e,#16213e,#0f3460)"></div>
        <?php endif; ?>
    </div>
    <div class="profile-overlay"></div>

    <!-- Profil kartı -->
    <div class="profile-card">
        <div class="profile-avatar-wrap">
            <?php if ($profile['avatar']): ?>
            <img class="profile-avatar" src="<?= APP_URL ?>/public/uploads/<?= e($profile['avatar']) ?>" alt="avatar">
            <?php else: ?>
            <div class="profile-avatar-placeholder"><?= e(strtoupper(substr($profile['display_name'] ?: $profile['username'], 0, 1))) ?></div>
            <?php endif; ?>
        </div>

        <div class="profile-display-name"><?= e($profile['display_name'] ?: $profile['username']) ?></div>
        <div class="profile-username">@<?= e($profile['username']) ?></div>

        <span class="badge profile-badge badge-<?= e($profile['role']) ?>"><?= e($profile['role']) ?></span>

        <div style="display:flex;justify-content:center;gap:2rem;margin-top:1.25rem">
            <div style="text-align:center">
                <div style="font-size:1.4rem;font-weight:700;color:#fff"><?= $post_count ?></div>
                <div style="font-size:.75rem;color:rgba(255,255,255,.6)">Forum Konusu</div>
            </div>
        </div>

        <div class="profile-joined">Katılım: <?= e($joined) ?></div>

        <?php if ($is_own): ?>
        <a href="<?= APP_URL ?>/pages/settings.php" class="profile-edit-btn">&#9881; Profili Düzenle</a>
        <?php endif; ?>

        <?php if (is_logged_in()): ?>
        <div style="margin-top:1rem">
            <a href="<?= APP_URL ?>/pages/dashboard.php" style="color:rgba(255,255,255,.6);font-size:.8rem">&#8592; Siteye Dön</a>
        </div>
        <?php else: ?>
        <div style="margin-top:1rem">
            <a href="<?= APP_URL ?>/pages/login.php" style="color:rgba(255,255,255,.6);font-size:.8rem">Giriş Yap</a>
        </div>
        <?php endif; ?>
    </div>
</div>

<script src="<?= APP_URL ?>/public/js/main.js"></script>
</body>
</html>
