<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';

function start_secure_session(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'secure'   => false,
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
        session_start();
    }
}

function generate_csrf(): string {
    start_secure_session();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf(string $token): bool {
    start_secure_session();
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(generate_csrf(), ENT_QUOTES) . '">';
}

function is_logged_in(): bool {
    start_secure_session();
    return isset($_SESSION['user_id']);
}

function current_user(): ?array {
    if (!is_logged_in()) return null;
    static $user = null;
    if ($user === null) {
        $pdo  = get_db();
        $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ? AND is_banned = 0');
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch() ?: null;
        if ($user === null) {
            logout();
        }
    }
    return $user;
}

function require_login(): void {
    if (!is_logged_in()) {
        header('Location: ' . APP_URL . '/pages/login.php');
        exit;
    }
    $u = current_user();
    if ($u === null) {
        header('Location: ' . APP_URL . '/pages/login.php?banned=1');
        exit;
    }
}

function require_role(string ...$roles): void {
    require_login();
    $user = current_user();
    if (!in_array($user['role'], $roles, true)) {
        http_response_code(403);
        die(render_403());
    }
}

function render_403(): string {
    return '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>403</title></head><body style="display:flex;align-items:center;justify-content:center;height:100vh;background:#111;color:#fff;font-family:sans-serif"><div style="text-align:center"><h1>403</h1><p>Bu sayfaya erişim yetkiniz yok.</p><a href="' . APP_URL . '/pages/dashboard.php" style="color:#4af">Geri dön</a></div></body></html>';
}

function login_user(string $username, string $password): array {
    $ip  = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $pdo = get_db();

    $stmt = $pdo->prepare('SELECT * FROM login_attempts WHERE ip = ? AND attempted_at > DATE_SUB(NOW(), INTERVAL ? MINUTE)');
    $stmt->execute([$ip, LOGIN_LOCKOUT_MINUTES]);
    if ($stmt->rowCount() >= LOGIN_MAX_ATTEMPTS) {
        return ['success' => false, 'message' => 'Çok fazla hatalı deneme. ' . LOGIN_LOCKOUT_MINUTES . ' dakika bekleyin.'];
    }

    $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ?');
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        $pdo->prepare('INSERT INTO login_attempts (ip, attempted_at) VALUES (?, NOW())')->execute([$ip]);
        return ['success' => false, 'message' => 'Kullanıcı adı veya şifre hatalı.'];
    }

    if ($user['is_banned']) {
        return ['success' => false, 'message' => 'Hesabınız banlanmıştır.'];
    }

    $pdo->prepare('DELETE FROM login_attempts WHERE ip = ?')->execute([$ip]);

    start_secure_session();
    session_regenerate_id(true);
    $_SESSION['user_id']   = $user['id'];
    $_SESSION['username']  = $user['username'];
    $_SESSION['role']      = $user['role'];

    if (!isset($_SESSION['theme'])) {
        $_SESSION['theme'] = $user['theme_color'] ?? DEFAULT_THEME;
    }

    return ['success' => true, 'user' => $user];
}

function logout(): void {
    start_secure_session();
    $_SESSION = [];
    session_destroy();
    header('Location: ' . APP_URL . '/pages/login.php');
    exit;
}
