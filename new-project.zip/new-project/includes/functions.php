<?php
function e(string $str): string {
    return htmlspecialchars($str, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function sanitize_filename(string $name): string {
    return preg_replace('/[^a-zA-Z0-9._-]/', '', basename($name));
}

function upload_error_message(int $code): string {
    return match($code) {
        UPLOAD_ERR_INI_SIZE   => 'Dosya sunucu limitini aşıyor (php.ini).',
        UPLOAD_ERR_FORM_SIZE  => 'Dosya form limitini aşıyor.',
        UPLOAD_ERR_PARTIAL    => 'Dosya kısmen yüklendi, tekrar deneyin.',
        UPLOAD_ERR_NO_FILE    => 'Hiçbir dosya seçilmedi.',
        UPLOAD_ERR_NO_TMP_DIR => 'Geçici dizin bulunamadı.',
        UPLOAD_ERR_CANT_WRITE => 'Dosya diske yazılamadı.',
        UPLOAD_ERR_EXTENSION  => 'Bir PHP eklentisi yüklemeyi durdurdu.',
        default               => 'Bilinmeyen yükleme hatası (kod: ' . $code . ').',
    };
}

function validate_upload(array $file, array $allowed_types, int $max_size): array {
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['valid' => false, 'message' => upload_error_message($file['error'])];
    }
    if ($file['size'] === 0) {
        return ['valid' => false, 'message' => 'Dosya boş.'];
    }
    if ($file['size'] > $max_size) {
        $mb = round($max_size / 1024 / 1024);
        return ['valid' => false, 'message' => "Dosya boyutu çok büyük. Maksimum: {$mb} MB."];
    }

    // Hem finfo hem de extension bazlı doğrulama
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime  = $finfo->file($file['tmp_name']);

    // Bazı tarayıcılar/sistemler farklı MIME döndürebilir, normalize et
    $mime_map = [
        'image/jpg'       => 'image/jpeg',
        'image/pjpeg'     => 'image/jpeg',
        'image/x-png'     => 'image/png',
        'video/x-msvideo' => 'video/avi',
    ];
    $mime = $mime_map[$mime] ?? $mime;

    // MIME listesi normalize et
    $normalized = array_map(fn($t) => $mime_map[$t] ?? $t, $allowed_types);

    if (!in_array($mime, $normalized, true)) {
        // Extension bazlı ikinci kontrol (bazı video formatları için)
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $ext_mime_map = [
            'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg',
            'png' => 'image/png',  'gif'  => 'image/gif',
            'webp'=> 'image/webp', 'bmp'  => 'image/bmp',
            'mp4' => 'video/mp4',  'webm' => 'video/webm',
            'avi' => 'video/avi',  'mov'  => 'video/quicktime',
            'mkv' => 'video/x-matroska', 'wmv' => 'video/x-ms-wmv',
            'ogg' => 'video/ogg',  'mpeg' => 'video/mpeg',
            '3gp' => 'video/3gpp',
        ];
        $ext_mime = $ext_mime_map[$ext] ?? '';
        if (!$ext_mime || !in_array($ext_mime, $normalized, true)) {
            return ['valid' => false, 'message' => "Desteklenmeyen dosya türü ({$mime}). Lütfen JPG, PNG, GIF, WEBP veya MP4, WEBM gibi formatlar kullanın."];
        }
        $mime = $ext_mime;
    }

    return ['valid' => true, 'mime' => $mime];
}

function save_upload(array $file, string $subdir, string $prefix = ''): string {
    $ext      = pathinfo($file['name'], PATHINFO_EXTENSION);
    $ext      = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $ext));
    $filename = $prefix . bin2hex(random_bytes(16)) . '.' . $ext;
    $dest     = UPLOAD_PATH . $subdir . '/' . $filename;
    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        throw new RuntimeException('Dosya kaydedilemedi.');
    }
    return $subdir . '/' . $filename;
}

function delete_upload(string $path): void {
    if (empty($path)) return;
    $full = UPLOAD_PATH . ltrim($path, '/');
    if (file_exists($full) && is_file($full)) {
        unlink($full);
    }
}

function validate_password_strength(string $pass): array {
    if (strlen($pass) < 8) {
        return ['valid' => false, 'message' => 'Şifre en az 8 karakter olmalıdır.'];
    }
    return ['valid' => true];
}

function set_flash(string $type, string $message): void {
    start_secure_session();
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash(): ?array {
    start_secure_session();
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function render_flash(): string {
    $flash = get_flash();
    if (!$flash) return '';
    $cls = $flash['type'] === 'success' ? 'alert-success' : 'alert-error';
    return '<div class="alert ' . $cls . '">' . e($flash['message']) . '</div>';
}

function paginate(int $total, int $per_page, int $current_page): array {
    $total_pages = max(1, (int)ceil($total / $per_page));
    $current_page = max(1, min($current_page, $total_pages));
    $offset = ($current_page - 1) * $per_page;
    return [
        'total'       => $total,
        'per_page'    => $per_page,
        'current'     => $current_page,
        'total_pages' => $total_pages,
        'offset'      => $offset,
    ];
}

function get_theme(): string {
    start_secure_session();
    return $_SESSION['theme'] ?? DEFAULT_THEME;
}
