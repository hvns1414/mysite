<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

function render_header(string $title = APP_NAME, bool $require_auth = true): void {
    if ($require_auth) require_login();
    $theme = get_theme();
    $user  = current_user();
    ?>
<!DOCTYPE html>
<html lang="tr" data-theme="<?= e($theme) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title) ?> — <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= APP_URL ?>/public/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="theme-<?= e($theme) ?>">
<nav class="navbar">
    <div class="nav-brand">
        <a href="<?= APP_URL ?>/pages/dashboard.php"><?= e(APP_NAME) ?></a>
    </div>
    <div class="nav-links">
        <a href="<?= APP_URL ?>/pages/forum.php">Forum</a>
        <a href="<?= APP_URL ?>/pages/chat.php">Chat</a>
        <a href="<?= APP_URL ?>/pages/voice_chat.php">Sesli</a>
        <?php if ($user && in_array($user['role'], ['root', 'admin'])): ?>
        <a href="<?= APP_URL ?>/admin/">Admin</a>
        <?php endif; ?>
    </div>
    <div class="nav-user">
        <?php if ($user): ?>
        <a href="<?= APP_URL ?>/u/?u=<?= e($user['username']) ?>" class="nav-avatar-link">
            <?php if ($user['avatar']): ?>
            <img src="<?= APP_URL ?>/public/uploads/<?= e($user['avatar']) ?>" class="nav-avatar" alt="avatar">
            <?php else: ?>
            <div class="nav-avatar nav-avatar-placeholder"><?= e(strtoupper(substr($user['display_name'] ?: $user['username'], 0, 1))) ?></div>
            <?php endif; ?>
            <span><?= e($user['display_name'] ?: $user['username']) ?></span>
        </a>
        <a href="<?= APP_URL ?>/pages/settings.php" class="btn-icon" title="Ayarlar">&#9881;</a>
        <a href="<?= APP_URL ?>/logout.php" class="btn-icon" title="Çıkış">&#9099;</a>
        <?php endif; ?>
    </div>
</nav>
<main class="main-content">
    <?= render_flash() ?>
    <?php
}

function render_footer(): void {
    ?>
</main>
<script src="<?= APP_URL ?>/public/js/main.js"></script>
</body>
</html>
<?php
}
