/* ===== voice.js — WebRTC ses + ekran paylaşımı ===== */
(function () {
    'use strict';

    var ws        = null;
    var peers     = {};  // peerId -> RTCPeerConnection
    var localStream      = null;
    var screenStream     = null;
    var isMuted          = false;
    var isScreenSharing  = false;
    var WS_URL           = 'ws://' + window.location.hostname + ':8080';
    var currentUser      = window.VOICE_USER || {};
    var roomId           = 'voice_room';

    var ICE_SERVERS = {
        iceServers: [
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' },
        ],
    };

    function init() {
        connectWS();
        bindControls();
    }

    /* ===== WebSocket ===== */
    function connectWS() {
        try {
            ws = new WebSocket(WS_URL);
        } catch (e) { return; }

        ws.onopen = function () {
            ws.send(JSON.stringify({
                type:    'voice_auth',
                user_id: currentUser.id,
                room:    roomId,
                token:   currentUser.ws_token,
            }));
        };

        ws.onmessage = function (e) {
            try { handleSignal(JSON.parse(e.data)); } catch (ex) {}
        };

        ws.onclose = function () {
            setTimeout(connectWS, 4000);
        };
    }

    function sendSignal(data) {
        if (ws && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify(data));
        }
    }

    /* ===== Signaling ===== */
    function handleSignal(data) {
        switch (data.type) {
            case 'voice_joined':
                addParticipant(data.user);
                break;
            case 'voice_left':
                removeParticipant(data.user_id);
                break;
            case 'voice_participants':
                (data.users || []).forEach(function (u) {
                    addParticipant(u);
                    if (localStream) createOffer(u.id);
                });
                break;
            case 'offer':
                handleOffer(data);
                break;
            case 'answer':
                if (peers[data.from]) peers[data.from].setRemoteDescription(new RTCSessionDescription(data.sdp)).catch(console.error);
                break;
            case 'ice_candidate':
                if (peers[data.from]) peers[data.from].addIceCandidate(new RTCIceCandidate(data.candidate)).catch(console.error);
                break;
        }
    }

    /* ===== Peer Management ===== */
    function createPeerConnection(peerId) {
        if (peers[peerId]) return peers[peerId];
        var pc = new RTCPeerConnection(ICE_SERVERS);
        peers[peerId] = pc;

        if (localStream) {
            localStream.getTracks().forEach(function (track) { pc.addTrack(track, localStream); });
        }

        pc.onicecandidate = function (e) {
            if (e.candidate) {
                sendSignal({ type: 'ice_candidate', to: peerId, candidate: e.candidate });
            }
        };

        pc.ontrack = function (e) {
            var el = document.getElementById('audio-' + peerId);
            if (!el) {
                el = document.createElement('audio');
                el.id      = 'audio-' + peerId;
                el.autoplay = true;
                document.body.appendChild(el);
            }
            el.srcObject = e.streams[0];

            // Ekran paylaşımı için video
            if (e.track.kind === 'video') {
                var screenArea = document.getElementById('screen-share-area');
                var vid        = document.getElementById('remote-screen');
                if (!vid) {
                    vid    = document.createElement('video');
                    vid.id = 'remote-screen';
                    vid.autoplay = true;
                    vid.style.width  = '100%';
                    vid.style.height = '100%';
                    screenArea.appendChild(vid);
                }
                vid.srcObject = e.streams[0];
                screenArea.classList.add('active');
            }
        };

        pc.onconnectionstatechange = function () {
            if (pc.connectionState === 'failed' || pc.connectionState === 'disconnected') {
                pc.close();
                delete peers[peerId];
            }
        };

        return pc;
    }

    function createOffer(peerId) {
        var pc = createPeerConnection(peerId);
        pc.createOffer().then(function (offer) {
            return pc.setLocalDescription(offer);
        }).then(function () {
            sendSignal({ type: 'offer', to: peerId, sdp: pc.localDescription });
        }).catch(console.error);
    }

    function handleOffer(data) {
        var pc = createPeerConnection(data.from);
        pc.setRemoteDescription(new RTCSessionDescription(data.sdp)).then(function () {
            return pc.createAnswer();
        }).then(function (answer) {
            return pc.setLocalDescription(answer);
        }).then(function () {
            sendSignal({ type: 'answer', to: data.from, sdp: pc.localDescription });
        }).catch(console.error);
    }

    /* ===== UI ===== */
    function addParticipant(user) {
        var container = document.getElementById('participants');
        if (!container || document.getElementById('p-' + user.id)) return;
        var div = document.createElement('div');
        div.className = 'voice-participant';
        div.id        = 'p-' + user.id;
        div.innerHTML =
            (user.avatar
                ? '<img class="voice-participant-avatar" src="/public/uploads/' + escHtml(user.avatar) + '">'
                : '<div class="voice-participant-placeholder">' + escHtml((user.display_name || user.username || '?')[0].toUpperCase()) + '</div>'
            ) +
            '<div style="font-weight:600;font-size:.9rem">' + escHtml(user.display_name || user.username) + '</div>' +
            '<div class="badge badge-' + escHtml(user.role || 'usr') + '">' + escHtml(user.role || 'usr') + '</div>';
        container.appendChild(div);
    }

    function removeParticipant(userId) {
        var el = document.getElementById('p-' + userId);
        if (el) el.remove();
        var audio = document.getElementById('audio-' + userId);
        if (audio) audio.remove();
        if (peers[userId]) { peers[userId].close(); delete peers[userId]; }
    }

    /* ===== Controls ===== */
    function bindControls() {
        var joinBtn   = document.getElementById('btn-join');
        var leaveBtn  = document.getElementById('btn-leave');
        var muteBtn   = document.getElementById('btn-mute');
        var screenBtn = document.getElementById('btn-screen');

        if (joinBtn) {
            joinBtn.addEventListener('click', function () {
                navigator.mediaDevices.getUserMedia({ audio: true }).then(function (stream) {
                    localStream = stream;
                    joinBtn.style.display  = 'none';
                    leaveBtn.style.display = '';
                    muteBtn.style.display  = '';
                    screenBtn.style.display = '';
                    sendSignal({ type: 'voice_join', room: roomId });
                }).catch(function (err) {
                    alert('Mikrofon erişimi reddedildi: ' + err.message);
                });
            });
        }

        if (leaveBtn) {
            leaveBtn.addEventListener('click', function () {
                if (localStream) { localStream.getTracks().forEach(function (t) { t.stop(); }); localStream = null; }
                if (screenStream) { screenStream.getTracks().forEach(function (t) { t.stop(); }); screenStream = null; }
                Object.values(peers).forEach(function (pc) { pc.close(); });
                peers = {};
                document.getElementById('participants').innerHTML = '';
                var screenArea = document.getElementById('screen-share-area');
                if (screenArea) screenArea.classList.remove('active');
                sendSignal({ type: 'voice_leave', room: roomId });
                joinBtn.style.display  = '';
                leaveBtn.style.display = 'none';
                muteBtn.style.display  = 'none';
                screenBtn.style.display = 'none';
            });
        }

        if (muteBtn) {
            muteBtn.addEventListener('click', function () {
                isMuted = !isMuted;
                if (localStream) {
                    localStream.getAudioTracks().forEach(function (t) { t.enabled = !isMuted; });
                }
                muteBtn.classList.toggle('active', isMuted);
                muteBtn.title = isMuted ? 'Sesi Aç' : 'Sesi Kapat';
                muteBtn.textContent = isMuted ? '🔇' : '🎤';
            });
        }

        if (screenBtn) {
            screenBtn.addEventListener('click', function () {
                if (!isScreenSharing) {
                    navigator.mediaDevices.getDisplayMedia({ video: true, audio: false }).then(function (stream) {
                        screenStream = stream;
                        isScreenSharing = true;
                        screenBtn.classList.add('active');
                        screenBtn.title = 'Ekran Paylaşımını Durdur';
                        var videoTrack = stream.getVideoTracks()[0];
                        Object.values(peers).forEach(function (pc) {
                            var sender = pc.getSenders().find(function (s) { return s.track && s.track.kind === 'video'; });
                            if (sender) { sender.replaceTrack(videoTrack); }
                            else { pc.addTrack(videoTrack, stream); }
                        });
                        videoTrack.addEventListener('ended', stopScreenShare);
                    }).catch(function () {});
                } else {
                    stopScreenShare();
                }
            });
        }
    }

    function stopScreenShare() {
        if (screenStream) { screenStream.getTracks().forEach(function (t) { t.stop(); }); screenStream = null; }
        isScreenSharing = false;
        var screenBtn = document.getElementById('btn-screen');
        if (screenBtn) { screenBtn.classList.remove('active'); screenBtn.title = 'Ekran Paylaş'; }
        var screenArea = document.getElementById('screen-share-area');
        if (screenArea) { screenArea.classList.remove('active'); screenArea.innerHTML = ''; }
    }

    function escHtml(str) {
        return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    document.addEventListener('DOMContentLoaded', init);
})();
