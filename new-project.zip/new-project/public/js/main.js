/* ===== main.js — tema değiştirme, genel yardımcılar ===== */
(function () {
    'use strict';

    // Tema değiştirme
    function applyTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        document.body.className = document.body.className.replace(/theme-\w+/, '');
        document.body.classList.add('theme-' + theme);
        document.querySelectorAll('.theme-swatch').forEach(function (el) {
            el.classList.toggle('selected', el.dataset.theme === theme);
        });
        localStorage.setItem('site_theme', theme);
    }

    function initTheme() {
        var savedTheme = localStorage.getItem('site_theme');
        var bodyTheme  = document.body.dataset.theme || document.documentElement.getAttribute('data-theme');
        var theme      = savedTheme || bodyTheme || 'white';
        applyTheme(theme);

        document.querySelectorAll('.theme-swatch').forEach(function (el) {
            el.addEventListener('click', function () {
                var t = el.dataset.theme;
                applyTheme(t);
                // Sunucuya kaydet
                fetch('/api/set_theme.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'theme=' + encodeURIComponent(t) + '&csrf_token=' + encodeURIComponent(getCSRFToken()),
                }).catch(function () {});
            });
        });
    }

    function getCSRFToken() {
        var el = document.querySelector('input[name="csrf_token"]');
        return el ? el.value : '';
    }

    // Avatar önizleme
    function initAvatarPreview() {
        var input   = document.getElementById('avatar_input');
        var preview = document.getElementById('avatar_preview_img');
        if (!input || !preview) return;
        input.addEventListener('change', function () {
            if (this.files && this.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) { preview.src = e.target.result; preview.style.display = 'block'; };
                reader.readAsDataURL(this.files[0]);
            }
        });
    }

    // Arka plan önizleme
    function initBgPreview() {
        var input   = document.getElementById('bg_input');
        var preview = document.getElementById('bg_preview');
        if (!input || !preview) return;
        input.addEventListener('change', function () {
            if (this.files && this.files[0]) {
                var url  = URL.createObjectURL(this.files[0]);
                var type = this.files[0].type;
                preview.innerHTML = type.startsWith('video/')
                    ? '<video src="' + url + '" autoplay muted loop style="max-width:100%;max-height:150px;border-radius:8px"></video>'
                    : '<img src="' + url + '" style="max-width:100%;max-height:150px;border-radius:8px">';
            }
        });
    }

    // Alert otomatik kapanma
    function initAlerts() {
        document.querySelectorAll('.alert').forEach(function (el) {
            setTimeout(function () {
                el.style.transition = 'opacity 0.5s';
                el.style.opacity    = '0';
                setTimeout(function () { el.remove(); }, 500);
            }, 4000);
        });
    }

    // Silme onayı
    document.querySelectorAll('[data-confirm]').forEach(function (el) {
        el.addEventListener('click', function (e) {
            if (!confirm(el.dataset.confirm || 'Emin misiniz?')) {
                e.preventDefault();
            }
        });
    });

    document.addEventListener('DOMContentLoaded', function () {
        initTheme();
        initAvatarPreview();
        initBgPreview();
        initAlerts();
    });
})();
