/* ===== chat.js — WebSocket tabanlı anlık chat ===== */
(function () {
    'use strict';

    var ws         = null;
    var reconnectT = null;
    var WS_URL     = 'ws://' + window.location.hostname + ':8080';
    var currentUser = null;
    var channel    = 'instant';

    function init() {
        currentUser = window.CHAT_USER || {};
        channel     = window.CHAT_CHANNEL || 'instant';
        connectWS();
        bindSend();
    }

    function connectWS() {
        setStatus('connecting');
        try {
            ws = new WebSocket(WS_URL);
        } catch (e) {
            setStatus('disconnected');
            scheduleReconnect();
            return;
        }

        ws.onopen = function () {
            setStatus('connected');
            clearTimeout(reconnectT);
            ws.send(JSON.stringify({
                type:    'auth',
                user_id: currentUser.id,
                channel: channel,
                token:   currentUser.ws_token,
            }));
        };

        ws.onmessage = function (event) {
            try {
                var data = JSON.parse(event.data);
                handleMessage(data);
            } catch (e) {}
        };

        ws.onclose = function () {
            setStatus('disconnected');
            scheduleReconnect();
        };

        ws.onerror = function () {
            setStatus('disconnected');
        };
    }

    function handleMessage(data) {
        if (data.type === 'message') {
            appendMessage(data);
        } else if (data.type === 'online_list') {
            updateOnlineList(data.users);
        } else if (data.type === 'error') {
            console.warn('WS error:', data.message);
        }
    }

    function appendMessage(msg) {
        var box = document.getElementById('chat-messages');
        if (!box) return;

        var div     = document.createElement('div');
        div.className = 'chat-message';
        div.dataset.id = msg.id || '';

        var avatarHtml = msg.avatar
            ? '<img class="chat-msg-avatar" src="/public/uploads/' + escHtml(msg.avatar) + '" alt="">'
            : '<div class="chat-msg-placeholder">' + escHtml((msg.display_name || msg.username || '?')[0].toUpperCase()) + '</div>';

        div.innerHTML =
            avatarHtml +
            '<div class="chat-msg-body">' +
            '<div class="chat-msg-meta">' +
            '<span class="chat-msg-user">' + escHtml(msg.display_name || msg.username) + '</span>' +
            '<span class="badge badge-' + escHtml(msg.role || 'usr') + '">' + escHtml(msg.role || 'usr') + '</span>' +
            '<span class="chat-msg-time">' + escHtml(msg.time || '') + '</span>' +
            '</div>' +
            '<div class="chat-msg-text">' + escHtml(msg.message) + '</div>' +
            '</div>';

        box.appendChild(div);
        box.scrollTop = box.scrollHeight;
    }

    function updateOnlineList(users) {
        var list = document.getElementById('online-list');
        if (!list) return;
        list.innerHTML = '';
        (users || []).forEach(function (u) {
            var div = document.createElement('div');
            div.className = 'online-user';
            div.innerHTML = '<div class="online-dot"></div>' + escHtml(u.display_name || u.username);
            list.appendChild(div);
        });
    }

    function bindSend() {
        var form  = document.getElementById('chat-form');
        var input = document.getElementById('chat-input');
        if (!form || !input) return;

        form.addEventListener('submit', function (e) {
            e.preventDefault();
            var msg = input.value.trim();
            if (!msg) return;
            if (ws && ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify({ type: 'message', message: msg, channel: channel }));
                input.value = '';
            } else {
                // AJAX fallback
                sendAjax(msg);
                input.value = '';
            }
        });

        input.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                form.dispatchEvent(new Event('submit'));
            }
        });
    }

    function sendAjax(msg) {
        var csrf = document.querySelector('input[name="csrf_token"]');
        fetch('/api/messages.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'message=' + encodeURIComponent(msg) +
                  '&channel=' + encodeURIComponent(channel) +
                  '&csrf_token=' + encodeURIComponent(csrf ? csrf.value : ''),
        }).then(function (r) { return r.json(); }).then(function (data) {
            if (data.msg) appendMessage(data.msg);
        }).catch(function () {});
    }

    function setStatus(state) {
        var el = document.getElementById('ws-status');
        if (!el) return;
        el.className    = 'ws-status ws-' + state;
        var labels      = { connected: 'Bağlı', disconnected: 'Bağlantı kesildi', connecting: 'Bağlanıyor...' };
        el.textContent  = labels[state] || state;
    }

    function scheduleReconnect() {
        clearTimeout(reconnectT);
        reconnectT = setTimeout(connectWS, 4000);
    }

    function escHtml(str) {
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    document.addEventListener('DOMContentLoaded', init);
})();
