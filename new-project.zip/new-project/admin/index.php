<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/layout.php';

require_role('root', 'admin');
render_header('Admin Paneli');
$user = current_user();
$pdo  = get_db();

$total_users  = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
$total_admins = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role IN ('root','admin')")->fetchColumn();
$total_banned = (int)$pdo->query('SELECT COUNT(*) FROM users WHERE is_banned = 1')->fetchColumn();
$total_posts  = (int)$pdo->query('SELECT COUNT(*) FROM forum_posts')->fetchColumn();
$total_msgs   = (int)$pdo->query('SELECT COUNT(*) FROM chat_messages')->fetchColumn();

$recent = $pdo->query('SELECT u.*, cb.username AS created_by_name FROM users u LEFT JOIN users cb ON cb.id = u.created_by ORDER BY u.created_at DESC LIMIT 10')->fetchAll();
?>
<div class="page-header">
    <h1>Admin Paneli</h1>
    <a href="<?= APP_URL ?>/admin/create_user.php" class="btn btn-primary">+ Kullanıcı Oluştur</a>
</div>

<?= render_flash() ?>

<div class="stats-grid">
    <div class="stat-card"><div class="stat-num"><?= $total_users ?></div><div class="stat-label">Toplam Kullanıcı</div></div>
    <div class="stat-card"><div class="stat-num"><?= $total_admins ?></div><div class="stat-label">Admin/Root</div></div>
    <div class="stat-card"><div class="stat-num"><?= $total_banned ?></div><div class="stat-label">Banlı</div></div>
    <div class="stat-card"><div class="stat-num"><?= $total_posts ?></div><div class="stat-label">Forum Konusu</div></div>
    <div class="stat-card"><div class="stat-num"><?= $total_msgs ?></div><div class="stat-label">Chat Mesajı</div></div>
</div>

<div class="card">
    <div class="card-title">Son Kayıtlar</div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Kullanıcı</th>
                    <th>Rol</th>
                    <th>Durum</th>
                    <th>Oluşturan</th>
                    <th>Tarih</th>
                    <th>İşlem</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recent as $u): ?>
                <tr>
                    <td>
                        <a href="<?= APP_URL ?>/u/?u=<?= e($u['username']) ?>">
                            <?= e($u['display_name'] ?: $u['username']) ?>
                        </a>
                        <div class="text-sm text-muted">@<?= e($u['username']) ?></div>
                    </td>
                    <td><span class="badge badge-<?= e($u['role']) ?>"><?= e($u['role']) ?></span></td>
                    <td><?= $u['is_banned'] ? '<span class="badge badge-banned">Banlı</span>' : '<span class="badge badge-usr" style="background:var(--success)">Aktif</span>' ?></td>
                    <td><?= e($u['created_by_name'] ?? '—') ?></td>
                    <td class="text-sm"><?= e(date('d.m.Y', strtotime($u['created_at']))) ?></td>
                    <td>
                        <a href="<?= APP_URL ?>/admin/manage_users.php?id=<?= (int)$u['id'] ?>" class="btn btn-ghost btn-sm">Yönet</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="mt-2">
        <a href="<?= APP_URL ?>/admin/manage_users.php" class="btn btn-ghost btn-sm">Tüm Kullanıcıları Gör</a>
    </div>
</div>
<?php render_footer(); ?>
