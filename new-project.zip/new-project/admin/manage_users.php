<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/layout.php';

require_role('root', 'admin');
render_header('Kullanıcı Yönetimi');
$admin = current_user();
$pdo   = get_db();

/* ===== POST: Ban / Unban / Rol değiştir ===== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        set_flash('error', 'Güvenlik doğrulaması başarısız.');
        header('Location: ' . $_SERVER['REQUEST_URI']);
        exit;
    }
    $target_id = (int)($_POST['target_id'] ?? 0);
    $action    = $_POST['action'] ?? '';

    $target = null;
    if ($target_id) {
        $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
        $stmt->execute([$target_id]);
        $target = $stmt->fetch();
    }

    if ($target && $target['id'] !== $admin['id']) {
        if ($action === 'ban' && $target['role'] !== 'root') {
            $pdo->prepare('UPDATE users SET is_banned = 1 WHERE id = ?')->execute([$target_id]);
            set_flash('success', $target['username'] . ' banlandı.');
        } elseif ($action === 'unban') {
            $pdo->prepare('UPDATE users SET is_banned = 0 WHERE id = ?')->execute([$target_id]);
            set_flash('success', $target['username'] . ' banı kaldırıldı.');
        } elseif ($action === 'set_role') {
            $new_role = $_POST['new_role'] ?? 'usr';
            if (!in_array($new_role, ['admin', 'usr'], true)) $new_role = 'usr';
            if ($target['role'] !== 'root') {
                $pdo->prepare('UPDATE users SET role = ? WHERE id = ?')->execute([$new_role, $target_id]);
                set_flash('success', $target['username'] . ' rolü güncellendi.');
            } else {
                set_flash('error', 'Root kullanıcısının rolü değiştirilemez.');
            }
        } elseif ($action === 'delete' && $admin['role'] === 'root' && $target['role'] !== 'root') {
            $pdo->prepare('DELETE FROM forum_replies WHERE user_id = ?')->execute([$target_id]);
            $pdo->prepare('DELETE FROM forum_posts WHERE user_id = ?')->execute([$target_id]);
            $pdo->prepare('DELETE FROM chat_messages WHERE user_id = ?')->execute([$target_id]);
            $pdo->prepare('DELETE FROM password_reset_tokens WHERE user_id = ?')->execute([$target_id]);
            if ($target['avatar']) delete_upload($target['avatar']);
            if ($target['background_url']) delete_upload($target['background_url']);
            $pdo->prepare('DELETE FROM users WHERE id = ?')->execute([$target_id]);
            set_flash('success', $target['username'] . ' silindi.');
        }
    } else {
        set_flash('error', 'Geçersiz işlem.');
    }

    header('Location: ' . APP_URL . '/admin/manage_users.php');
    exit;
}

/* ===== Tek kullanıcı görünümü ===== */
$single_id = (int)($_GET['id'] ?? 0);
$single    = null;
if ($single_id) {
    $stmt = $pdo->prepare('SELECT u.*, cb.username AS creator FROM users u LEFT JOIN users cb ON cb.id = u.created_by WHERE u.id = ?');
    $stmt->execute([$single_id]);
    $single = $stmt->fetch();
}

/* ===== Kullanıcı listesi ===== */
$search = trim($_GET['q'] ?? '');
$page   = max(1, (int)($_GET['page'] ?? 1));
$per    = 20;

if ($search) {
    $count_stmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE username LIKE ? OR display_name LIKE ? OR email LIKE ?');
    $count_stmt->execute(['%'.$search.'%', '%'.$search.'%', '%'.$search.'%']);
} else {
    $count_stmt = $pdo->query('SELECT COUNT(*) FROM users');
}
$total = (int)$count_stmt->fetchColumn();
$pagi  = paginate($total, $per, $page);

if ($search) {
    $stmt = $pdo->prepare('SELECT * FROM users WHERE username LIKE ? OR display_name LIKE ? OR email LIKE ? ORDER BY created_at DESC LIMIT ? OFFSET ?');
    $stmt->bindValue(1, '%'.$search.'%');
    $stmt->bindValue(2, '%'.$search.'%');
    $stmt->bindValue(3, '%'.$search.'%');
    $stmt->bindValue(4, $per, PDO::PARAM_INT);
    $stmt->bindValue(5, $pagi['offset'], PDO::PARAM_INT);
} else {
    $stmt = $pdo->prepare('SELECT * FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?');
    $stmt->bindValue(1, $per, PDO::PARAM_INT);
    $stmt->bindValue(2, $pagi['offset'], PDO::PARAM_INT);
}
$stmt->execute();
$users = $stmt->fetchAll();
?>
<div class="page-header">
    <h1>Kullanıcı Yönetimi</h1>
    <a href="<?= APP_URL ?>/admin/create_user.php" class="btn btn-primary btn-sm">+ Yeni Kullanıcı</a>
</div>

<?= render_flash() ?>

<?php if ($single): ?>
<!-- Tek Kullanıcı Detayı -->
<div class="card mb-2">
    <div class="card-title">
        <?= e($single['display_name'] ?: $single['username']) ?>
        <span class="badge badge-<?= e($single['role']) ?>"><?= e($single['role']) ?></span>
        <?php if ($single['is_banned']): ?><span class="badge badge-banned">Banlı</span><?php endif; ?>
    </div>
    <div class="grid-2">
        <div>
            <p class="text-sm"><strong>Kullanıcı Adı:</strong> <?= e($single['username']) ?></p>
            <p class="text-sm"><strong>E-posta:</strong> <?= e($single['email']) ?></p>
            <p class="text-sm"><strong>Oluşturan:</strong> <?= e($single['creator'] ?? '—') ?></p>
            <p class="text-sm"><strong>Katılım:</strong> <?= e(date('d.m.Y H:i', strtotime($single['created_at']))) ?></p>
        </div>
        <?php if ($single['avatar']): ?>
        <div><img src="<?= APP_URL ?>/public/uploads/<?= e($single['avatar']) ?>" style="width:72px;height:72px;border-radius:50%;object-fit:cover"></div>
        <?php endif; ?>
    </div>

    <?php if ($single['id'] !== $admin['id'] && $single['role'] !== 'root'): ?>
    <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-top:1rem">
        <?php if (!$single['is_banned']): ?>
        <form method="POST">
            <?= csrf_field() ?>
            <input type="hidden" name="target_id" value="<?= (int)$single['id'] ?>">
            <input type="hidden" name="action" value="ban">
            <button type="submit" class="btn btn-danger btn-sm" data-confirm="Bu kullanıcıyı banlamak istediğinizden emin misiniz?">Banla</button>
        </form>
        <?php else: ?>
        <form method="POST">
            <?= csrf_field() ?>
            <input type="hidden" name="target_id" value="<?= (int)$single['id'] ?>">
            <input type="hidden" name="action" value="unban">
            <button type="submit" class="btn btn-success btn-sm">Banı Kaldır</button>
        </form>
        <?php endif; ?>

        <form method="POST" style="display:flex;gap:.5rem;align-items:center">
            <?= csrf_field() ?>
            <input type="hidden" name="target_id" value="<?= (int)$single['id'] ?>">
            <input type="hidden" name="action" value="set_role">
            <select name="new_role" class="form-control" style="width:auto;padding:.35rem .7rem">
                <option value="usr"   <?= $single['role'] === 'usr'   ? 'selected' : '' ?>>usr</option>
                <option value="admin" <?= $single['role'] === 'admin' ? 'selected' : '' ?>>admin</option>
            </select>
            <button type="submit" class="btn btn-ghost btn-sm">Rolü Güncelle</button>
        </form>

        <?php if ($admin['role'] === 'root'): ?>
        <form method="POST">
            <?= csrf_field() ?>
            <input type="hidden" name="target_id" value="<?= (int)$single['id'] ?>">
            <input type="hidden" name="action" value="delete">
            <button type="submit" class="btn btn-danger btn-sm" data-confirm="Kullanıcıyı kalıcı olarak silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.">Sil</button>
        </form>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <div class="mt-2"><a href="<?= APP_URL ?>/admin/manage_users.php" class="btn btn-ghost btn-sm">&#8592; Listeye Dön</a></div>
</div>
<?php endif; ?>

<!-- Arama + Liste -->
<div class="card">
    <div style="display:flex;gap:.5rem;margin-bottom:1rem">
        <form method="GET" style="display:flex;gap:.5rem;flex:1">
            <input type="text" name="q" class="form-control" placeholder="Kullanıcı ara..." value="<?= e($search) ?>">
            <button type="submit" class="btn btn-ghost">Ara</button>
            <?php if ($search): ?><a href="<?= APP_URL ?>/admin/manage_users.php" class="btn btn-ghost">Temizle</a><?php endif; ?>
        </form>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr><th>Kullanıcı</th><th>E-posta</th><th>Rol</th><th>Durum</th><th>Katılım</th><th></th></tr>
            </thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                <tr>
                    <td>
                        <a href="<?= APP_URL ?>/u/?u=<?= e($u['username']) ?>"><?= e($u['display_name'] ?: $u['username']) ?></a>
                        <div class="text-sm text-muted">@<?= e($u['username']) ?></div>
                    </td>
                    <td class="text-sm"><?= e($u['email']) ?></td>
                    <td><span class="badge badge-<?= e($u['role']) ?>"><?= e($u['role']) ?></span></td>
                    <td><?= $u['is_banned'] ? '<span class="badge badge-banned">Banlı</span>' : '<span style="color:var(--success);font-size:.8rem">&#9679; Aktif</span>' ?></td>
                    <td class="text-sm"><?= e(date('d.m.Y', strtotime($u['created_at']))) ?></td>
                    <td><a href="?id=<?= (int)$u['id'] ?>" class="btn btn-ghost btn-sm">Yönet</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <?php if ($pagi['total_pages'] > 1): ?>
    <div class="pagination">
        <?php for ($i = 1; $i <= $pagi['total_pages']; $i++): ?>
        <a href="?page=<?= $i ?><?= $search ? '&q='.urlencode($search) : '' ?>" class="<?= $i === $pagi['current'] ? 'current' : '' ?>"><?= $i ?></a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>
<?php render_footer(); ?>
