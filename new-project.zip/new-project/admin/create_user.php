<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/layout.php';

require_role('root', 'admin');
render_header('Kullanıcı Oluştur');
$admin = current_user();
$pdo   = get_db();

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Güvenlik doğrulaması başarısız.';
    } else {
        $username     = trim($_POST['username'] ?? '');
        $email        = trim($_POST['email'] ?? '');
        $password     = $_POST['password'] ?? '';
        $display_name = trim($_POST['display_name'] ?? '');
        $role         = $_POST['role'] ?? 'usr';

        if (!in_array($role, ['admin', 'usr'], true)) $role = 'usr';

        if (strlen($username) < 3 || strlen($username) > 50) {
            $error = 'Kullanıcı adı 3-50 karakter arasında olmalıdır.';
        } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
            $error = 'Kullanıcı adı yalnızca harf, rakam ve alt çizgi içerebilir.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Geçerli bir e-posta adresi girin.';
        } else {
            $check = validate_password_strength($password);
            if (!$check['valid']) { $error = $check['message']; }
            else {
                $stmt = $pdo->prepare('SELECT id FROM users WHERE username = ? OR email = ?');
                $stmt->execute([$username, $email]);
                if ($stmt->fetch()) {
                    $error = 'Bu kullanıcı adı veya e-posta zaten kullanılıyor.';
                } else {
                    $hash = password_hash($password, PASSWORD_BCRYPT);
                    $pdo->prepare('INSERT INTO users (username, email, password, display_name, role, created_by) VALUES (?, ?, ?, ?, ?, ?)')
                        ->execute([$username, $email, $hash, $display_name, $role, $admin['id']]);
                    $success = 'Kullanıcı "' . htmlspecialchars($username) . '" başarıyla oluşturuldu.';
                }
            }
        }
    }
}
?>
<div class="page-header">
    <h1>Kullanıcı Oluştur</h1>
    <a href="<?= APP_URL ?>/admin/" class="btn btn-ghost btn-sm">&#8592; Admin Paneli</a>
</div>

<?php if ($error):   ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>

<div class="card" style="max-width:520px">
    <div class="card-title">Yeni Kullanıcı</div>
    <form method="POST">
        <?= csrf_field() ?>
        <div class="form-group">
            <label class="form-label" for="username">Kullanıcı Adı *</label>
            <input type="text" id="username" name="username" class="form-control"
                   value="<?= e($_POST['username'] ?? '') ?>" maxlength="50" required pattern="[a-zA-Z0-9_]+">
            <div class="text-sm text-muted mt-1">Yalnızca harf, rakam ve alt çizgi</div>
        </div>
        <div class="form-group">
            <label class="form-label" for="email">E-posta *</label>
            <input type="email" id="email" name="email" class="form-control"
                   value="<?= e($_POST['email'] ?? '') ?>" required>
        </div>
        <div class="form-group">
            <label class="form-label" for="display_name">Görünen Ad</label>
            <input type="text" id="display_name" name="display_name" class="form-control"
                   value="<?= e($_POST['display_name'] ?? '') ?>" maxlength="100">
        </div>
        <div class="form-group">
            <label class="form-label" for="password">Şifre *</label>
            <input type="password" id="password" name="password" class="form-control" required minlength="8">
            <div class="text-sm text-muted mt-1">En az 8 karakter</div>
        </div>
        <div class="form-group">
            <label class="form-label" for="role">Yetki Seviyesi *</label>
            <select id="role" name="role" class="form-control">
                <option value="usr"   <?= ($_POST['role'] ?? 'usr') === 'usr'   ? 'selected' : '' ?>>Kullanıcı (usr)</option>
                <option value="admin" <?= ($_POST['role'] ?? '') === 'admin' ? 'selected' : '' ?>>Admin</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary w-full">Kullanıcı Oluştur</button>
    </form>
</div>
<?php render_footer(); ?>
